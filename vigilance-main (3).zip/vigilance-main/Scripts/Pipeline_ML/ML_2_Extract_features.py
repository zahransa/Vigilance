#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 17 14:54:03 2022

Scripts that creates epochs from rating windows.

@author: nicolaiwolpert
"""

import numpy as np
import pandas as pd
import math
import os
import matplotlib
import matplotlib.pyplot as plt
import random
import seaborn as sns
import scipy
from scipy import stats
import mne
from mne import create_info, concatenate_raws
from mne.channels import make_standard_montage
from mne.io import RawArray
from mne import EpochsArray
from mne.datasets import sample
from mne.preprocessing import create_ecg_epochs, create_eog_epochs

from scipy.integrate import simps

import neurokit2 as nk

from Scripts.vigilance_tools import *

import warnings
warnings.simplefilter("ignore")

plt.close('all')

root = os.path.dirname(os.getcwd())
root = os.path.join(root, 'Vigilance')

raw_dir = os.path.join(root, 'Data_raw')
eeg_dir = os.path.join(raw_dir, 'EEG')
behavior_dir = os.path.join(raw_dir, 'Behavior')
data_work_path = root + '/Data_work/'

# Specify subjects for the different tasks with clean EEG & behavior
tasks_subjects = {'atc': ['01', '03', '04', '05', '08', '15', '21', '23', '24'],
                  'line_task_sim': ['02', '03', '04', '18', '25'],
                  'line_task_succ': ['02', '04', '05', '07'],
                  'oddball': ['04', '07']}

# Choose if to use EEG cleaned from artifacts or not
clean_EEG_artifacts = True

# Specify sample frequency
SFREQ = 250

# Specify length of epochs (in seconds)
epoch_duration = 5

# Specify frequency bands of interest
FREQ_BANDS = {"delta": [0.5, 4.5],
              "theta": [4.5, 8],
              "alpha": [8, 13],
              "beta": [13, 30]}

# specify eeg channels
EEG_CHANNELS = ['Pz','O1','O2','F3','F4','Fp1','Fp2']

eeg_epochs_all = pd.read_csv(data_work_path + f'ML/epochs/eeg_epochs_all_{epoch_duration}_seconds.csv', index_col=0, dtype={'subject_id': str})
ecg_epochs_all = pd.read_csv(data_work_path + f'ML/epochs/ecg_epochs_all_{epoch_duration}_seconds.csv', index_col=0, dtype={'subject_id': str})

# Select z-threshold for blink detection
thresh_z_blinks = 2.5
padding_blinks = 0.1    # in seconds
padding_blinks_samples = padding_blinks * SFREQ

### Helper functions
# Transforming from csv to raw
def transform_raw(data_csv):
    if 'timestamp' in data_csv.columns:
        data_csv.set_index('timestamp', inplace=True)
    # transform to raw format
    d = data_csv.copy()
    ch_names = list(d.columns.values)
    # ch_names[ch_names.index('ECG')] = 'Fz'
    # ch_types = ['eeg'] * 3 + ['ecg'] + ['eeg'] * 4 + ['stim']
    # ECG has to be treated like EEG channel, else notch filter doesn't work
    ch_types = ['eeg'] * (len(data_csv.columns) - 1) + ['stim']
    dValues = d.values.T
    dValues[:len(ch_names) - 1] *= 1e-6  # convert from Volts into µVolts

    infor = create_info(ch_names, SFREQ, ch_types)
    data_raw = RawArray(dValues, info=infor, verbose=False)
    data_raw.set_montage(make_standard_montage('standard_1020'))

    return data_raw

# Computing band power
def eeg_band(data, psd_window_size_sec = 4, psd_window_overlap = 0.5):
    channel_names = data.copy().info.ch_names
    channel_names.remove('trigger')
    if channel_names != EEG_CHANNELS:
        raise ValueError('EEG channels in data do not correspond to EEG_CHANNELS as defined')

    absolute_power_per_channel_band = pd.DataFrame(columns = ['channel'] + list(FREQ_BANDS.keys()))
    absolute_power_per_channel_band['channel'] = EEG_CHANNELS
    absolute_power_per_channel_band.set_index('channel', inplace=True)
    normalized_power_per_channel_band = absolute_power_per_channel_band.copy()

    window_size_samples = psd_window_size_sec * SFREQ
    samples_overlap = int(window_size_samples * psd_window_overlap)
    psds, freqs = mne.time_frequency.psd_welch(data, picks='eeg', fmin=0.5, fmax=30, n_fft=window_size_samples, n_overlap=samples_overlap)
    # Absolute bandpower
    for freq_band in FREQ_BANDS.keys():
        # Absolute power = area under the curve
        absolute_power_per_channel_band[freq_band] = \
            simps(psds[:, (freqs >= FREQ_BANDS[freq_band][0]) & (freqs < FREQ_BANDS[freq_band][1])], dx=SFREQ)

    # Normalized bandpower = absolute power divided by total power
    for freq_band in FREQ_BANDS.keys():
        for channel in channel_names:
            normalized_power_per_channel_band.loc[channel, freq_band] = \
                absolute_power_per_channel_band.loc[channel, freq_band] / absolute_power_per_channel_band.loc[channel].sum()

    return absolute_power_per_channel_band, normalized_power_per_channel_band

### Compute features
# epoch_in_rating_window: Notes number of epoch relative to the current block & rating window.
# epoch_overall: Notes number of general epoch irrespective of block and rating window.
eeg_feature_frame = pd.DataFrame(columns = ['task', 'subject_id', 'epoch', 'vigilance_label'])
ecg_feature_frame = pd.DataFrame(columns = ['task', 'subject_id', 'epoch', 'vigilance_label'])
for task in tasks_subjects.keys():
    for subject_id in tasks_subjects[task]:

        print(f'##### Extracting EEG+ECG features for task {task}, subject {subject_id}...')

        task_subject = task + '_' + subject_id
        eeg_epochs_subject = eeg_epochs_all.loc[eeg_epochs_all.task_subject==task_subject]
        ecg_epochs_subject = ecg_epochs_all.loc[ecg_epochs_all.task_subject==task_subject]
        epoch_numbers = list(pd.unique(eeg_epochs_subject.epoch))

        for iepoch in epoch_numbers:

            ### EEG features
            eeg_epoch_csv = eeg_epochs_subject.loc[eeg_epochs_subject.epoch == iepoch]

            vigilance_label = list(eeg_epoch_csv.vigilance_label)[0]
            eeg_epoch_csv.drop(['task_subject', 'epoch', 'vigilance_label'], axis=1, inplace=True)
            if 'rating' in eeg_epoch_csv.columns:
                eeg_epoch_csv.drop(['rating'], axis=1, inplace=True)
            eeg_epoch_csv.set_index('timestamp', inplace=True)
            eeg_epoch = transform_raw(eeg_epoch_csv)

            eeg_feature_frame = eeg_feature_frame.append(
                pd.DataFrame({'task_subject': [task + '_' + subject_id], 'epoch': [iepoch], 'vigilance_label': [vigilance_label]}),
                ignore_index=True
            )

            # Compute absolute and normalized bandpower for each channel and frequency
            absolute_power_per_channel_band, normalized_power_per_channel_band = eeg_band(eeg_epoch)
            # Note in eeg feature frame
            for freq_band in FREQ_BANDS.keys():
                for channel in EEG_CHANNELS:

                    # note index of current epoch in feature frame to save lines
                    idx_feature_frame = eeg_feature_frame.loc[(eeg_feature_frame.task_subject == (task + '_' + subject_id)) &
                                                              (eeg_feature_frame.epoch == iepoch)].index[0]

                    # Note absolute and normalized EEG bandpass power
                    eeg_feature_frame.loc[idx_feature_frame, channel + '-' + freq_band + '-abs'] = \
                        absolute_power_per_channel_band.loc[channel, freq_band]

                    eeg_feature_frame.loc[idx_feature_frame, channel + '-' + freq_band + '-norm'] = \
                        normalized_power_per_channel_band.loc[channel, freq_band]

                ### Compute hemispheric bandpower
                absolute_eegbandpowerright = np.nanmean([absolute_power_per_channel_band.loc['O2', freq_band],
                                                         absolute_power_per_channel_band.loc['F4', freq_band],
                                                         absolute_power_per_channel_band.loc['Fp2', freq_band]])
                eeg_feature_frame.loc[idx_feature_frame, 'right-' + freq_band + '-abs'] = \
                    absolute_eegbandpowerright

                absolute_eegbandpowerleft = np.nanmean([absolute_power_per_channel_band.loc['O1', freq_band],
                                                        absolute_power_per_channel_band.loc['F3', freq_band],
                                                        absolute_power_per_channel_band.loc['Fp1', freq_band]])
                eeg_feature_frame.loc[idx_feature_frame, 'left-' + freq_band + '-abs'] = \
                    absolute_eegbandpowerleft

                normalized_eegbandpowerright = np.nanmean([normalized_power_per_channel_band.loc['O2', freq_band],
                                                           normalized_power_per_channel_band.loc['F4', freq_band],
                                                           normalized_power_per_channel_band.loc['Fp2', freq_band]])
                eeg_feature_frame.loc[idx_feature_frame, 'right-' + freq_band + '-norm'] = \
                    normalized_eegbandpowerright

                normalized_eegbandpowerleft = np.nanmean([normalized_power_per_channel_band.loc['O1', freq_band],
                                                          normalized_power_per_channel_band.loc['F3', freq_band],
                                                          normalized_power_per_channel_band.loc['Fp1', freq_band]])
                eeg_feature_frame.loc[idx_feature_frame, 'left' + freq_band + '-norm'] = \
                    normalized_eegbandpowerleft

                power_asymmetry_O2O1 = (
                        absolute_power_per_channel_band.loc['O2', freq_band] - absolute_power_per_channel_band.loc['O1', freq_band])
                eeg_feature_frame.loc[idx_feature_frame, freq_band + '-pow_asym-O2O1'] = \
                    power_asymmetry_O2O1
                power_asymmetry_F4F3 = (
                        absolute_power_per_channel_band.loc['F4', freq_band] - absolute_power_per_channel_band.loc['F3', freq_band])
                eeg_feature_frame.loc[idx_feature_frame, freq_band + '-pow_asym-F4F3'] = \
                    power_asymmetry_F4F3
                power_asymmetry_FP2FP1 = (
                        absolute_power_per_channel_band.loc['Fp2', freq_band] - absolute_power_per_channel_band.loc[
                    'Fp1', freq_band])
                eeg_feature_frame.loc[idx_feature_frame, freq_band + '-pow_asym-FP2FP1'] = \
                    power_asymmetry_FP2FP1

                power_asymmetry_rightleft = absolute_eegbandpowerright - absolute_eegbandpowerleft
                eeg_feature_frame.loc[idx_feature_frame, freq_band + '-pow_asym-RL'] = \
                    power_asymmetry_rightleft

            for channel in EEG_CHANNELS:
                # total band power per channel across frequencies
                eeg_feature_frame.loc[idx_feature_frame, 'total_power-' + channel] = \
                    np.nansum(absolute_power_per_channel_band.loc[channel])

                # power ratio between frequency bands per channel
                powerratio_delta_theta = absolute_power_per_channel_band.loc[channel, 'delta'] / \
                                         absolute_power_per_channel_band.loc[channel, 'theta']
                eeg_feature_frame.loc[idx_feature_frame, 'PR-delta-theta-' + channel] = \
                    powerratio_delta_theta
                powerratio_delta_alpha = absolute_power_per_channel_band.loc[channel, 'delta'] / \
                                         absolute_power_per_channel_band.loc[channel, 'alpha']
                eeg_feature_frame.loc[idx_feature_frame, 'PR-delta-alpha-' + channel] = \
                    powerratio_delta_alpha
                powerratio_delta_beta = absolute_power_per_channel_band.loc[channel, 'delta'] / \
                                        absolute_power_per_channel_band.loc[channel, 'beta']
                eeg_feature_frame.loc[idx_feature_frame, 'PR-delta-beta-' + channel] = \
                    powerratio_delta_beta

                powerratio_theta_beta = absolute_power_per_channel_band.loc[channel, 'theta'] / \
                                        absolute_power_per_channel_band.loc[channel, 'beta']
                eeg_feature_frame.loc[idx_feature_frame, 'PR-theta-beta-' + channel] = \
                    powerratio_theta_beta
                powerratio_theta_alpha = absolute_power_per_channel_band.loc[channel, 'theta'] / \
                                         absolute_power_per_channel_band.loc[channel, 'alpha']
                eeg_feature_frame.loc[idx_feature_frame, 'PR-theta-alpha-' + channel] = \
                    powerratio_theta_alpha

                powerratio_alpha_beta = absolute_power_per_channel_band.loc[channel, 'alpha'] / \
                                        absolute_power_per_channel_band.loc[channel, 'beta']
                eeg_feature_frame.loc[idx_feature_frame, 'PR-alpha-beta-' + channel] = \
                    powerratio_alpha_beta

            # total band power across channel
            eeg_feature_frame.loc[idx_feature_frame, 'total_power'] = \
                np.nansum(absolute_power_per_channel_band)

            ### Blinks
            # Need at least 30seconds  to reliably compute blink rate
            if epoch_duration >= 30:
                blinks_starts_ends_samples, blinks_timestamps = detect_blinks(eeg_epoch_csv, thresh_z_blinks,
                                                                              padding_blinks_samples, task, subject_id,
                                                                              visualize=False)
                if type(blinks_starts_ends_samples)==float and np.isnan(blinks_starts_ends_samples):

                    eeg_feature_frame.loc[idx_feature_frame, 'blink_rate'] = np.nan
                else:
                    nblinks = blinks_starts_ends_samples.shape[0]
                    nblinks_per_minute = nblinks * (60 / epoch_duration)

                    eeg_feature_frame.loc[idx_feature_frame, 'blink_rate'] = nblinks_per_minute

            ### ECG features

            ecg_epoch = ecg_epochs_subject.loc[ecg_epochs_subject.epoch == iepoch]
            ecg_signal = ecg_epoch['ECG']
            timestamps = [x / SFREQ for x in list(range(0, len(ecg_signal)))]

            # Need at least 30 seconds to compute ECG features
            if epoch_duration >= 30:
                df_raw, info = nk.ecg_process(ecg_signal, sampling_rate=SFREQ)
                ecg_features = nk.ecg_analyze(df_raw, sampling_rate=SFREQ, method="interval-related")
                # Some values are wrapped in lists, flatten
                for feat in ecg_features.columns:
                    if type(ecg_features[feat][0])==np.ndarray:
                        ecg_features[feat] = ecg_features[feat][0][0][0]

                ecg_feature_frame = ecg_feature_frame.append(
                    pd.concat([pd.DataFrame({'task_subject': [task + '_' + subject_id], 'epoch': [iepoch],
                                             'vigilance_label': [vigilance_label]}),
                               ecg_features], axis=1), ignore_index=True
                )

                '''
                signal_quality = df_raw.ECG_Quality
                samples_Rpeaks = list(df_raw[df_raw.ECG_R_Peaks == 1].index)
                timestamps_Rpeaks = [timestamps[i] for i in samples_Rpeaks] #samples_Rpeaks / SFREQ
            
                fig, axs = plt.subplots(2, 1, figsize=(10, 5), sharex=True)
                axs = axs.flatten()
                axs[0].plot(timestamps, ecg_signal)
                axs[0].scatter(timestamps_Rpeaks, [ecg_signal[i] for i in samples_Rpeaks], color='red')
                axs[0].set_title('Subject' + subject + ', ECG, with Rpeaks before cleaning', fontsize=12)
                axs[1].plot(timestamps, signal_quality)
                axs[1].axhline(y=thresh_ECG_quality, color='r', linestyle='--')
                axs[1].set_title('ECG Quality', fontsize=12)
                plt.show()
            
                df_clean = clean_Rpeaks(df_raw, threshold_distance_merge, thresh_ECG_quality, padding, SFREQ)
            
                signal_quality = df_clean.ECG_Quality
                samples_Rpeaks = df_clean[df_clean.ECG_R_Peaks==1].index
                timestamps_Rpeaks = samples_Rpeaks/SFREQ
            
                fig, axs = plt.subplots(2,1,figsize=(10,5), sharex=True)
                axs = axs.flatten()
                axs[0].plot(timestamps, ecg_signal)
                axs[0].scatter(timestamps_Rpeaks, ecg_signal[samples_Rpeaks], color='red')
                axs[0].set_title('ECG, with Rpeaks after cleaning, threshold_distance_merge=' + str(threshold_distance_merge) + ', padding=' + str(padding), fontsize=12)
                axs[1].plot(timestamps, signal_quality)
                axs[1].axhline(y=thresh_ECG_quality, color='r', linestyle='--')
                axs[1].set_title('ECG Quality', fontsize=12)
                plt.show()
                '''

# Discard features with all nan
eeg_feature_frame.dropna(axis=1, how='all', inplace=True)
ecg_feature_frame.dropna(axis=1, how='all', inplace=True)
if ecg_feature_frame.shape[0] > 0:
    eeg_ecg_feature_frame = pd.merge(eeg_feature_frame, ecg_feature_frame, on=['task_subject', 'epoch', 'vigilance_label'])
    ecg_feature_frame.to_csv(data_work_path + f'ML/feature_frames/ecg_feature_frame_{epoch_duration}second_epochs.csv', index=False)
    eeg_ecg_feature_frame.to_csv(data_work_path + f'ML/feature_frames/eeg_ecg_feature_frame_{epoch_duration}second_epochs.csv', index=False)

eeg_feature_frame.to_csv(data_work_path + f'ML/feature_frames/eeg_feature_frame_{epoch_duration}second_epochs.csv', index=False)


### Investigate percentage of missing values for features

pd.set_option('display.max_rows', eeg_ecg_feature_frame.shape[0])
percent_missing = eeg_ecg_feature_frame.isnull().sum() * 100 / len(eeg_ecg_feature_frame)
missing_value_df = pd.DataFrame({'column_name': eeg_ecg_feature_frame.columns,
                                 'percent_missing': percent_missing})
missing_value_df.sort_values('percent_missing', ascending=False, inplace=True)

