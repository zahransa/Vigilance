#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 17 14:54:03 2022

Scripts that creates epochs from rating windows.

@author: nicolaiwolpert
"""

import numpy as np
import pandas as pd
import math
import os
import matplotlib
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler,MinMaxScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.svm import SVC, LinearSVC
from sklearn.model_selection import GridSearchCV, KFold, cross_validate
from sklearn.pipeline import make_pipeline
from skopt import BayesSearchCV
from sklearn.metrics import cohen_kappa_score
import itertools

from Scripts.vigilance_tools import *

import warnings
warnings.simplefilter("ignore")

plt.close('all')

root = os.path.dirname(os.getcwd())
root = os.path.join(root, 'Vigilance')

raw_dir = os.path.join(root, 'Data_raw')
eeg_dir = os.path.join(raw_dir, 'EEG')
behavior_dir = os.path.join(raw_dir, 'Behavior')
data_work_path = root + '/Data_work/'

# Specify subjects for the different tasks with clean EEG & behavior
tasks_subjects = {'atc': ['01', '03', '04', '05', '08', '15', '21', '23', '24'],
                  'line_task_sim': ['02', '03', '04', '18', '25'],
                  'line_task_succ': ['02', '04', '05', '07'],
                  'oddball': ['04', '07']}

# Choose if to use EEG cleaned from artifacts or not
clean_EEG_artifacts = True

# Specify sample frequency
SFREQ = 250

# Specify length of epochs (in seconds)
epoch_duration = 5

# Choose features: 'eeg', 'ecg' or 'eeg_ecg'
input_features = 'eeg'

### Load feature frame
if input_features=='eeg':
    filename_feature_frame = data_work_path + f'ML/feature_frames/eeg_feature_frame_{epoch_duration}second_epochs.csv'
elif input_features=='ecg':
    filename_feature_frame = data_work_path + f'ML/feature_frames/ecg_feature_frame_{epoch_duration}second_epochs.csv'
elif (input_features=='eeg_ecg'):
    filename_feature_frame = data_work_path + f'ML/feature_frames/eeg_ecg_feature_frame_{epoch_duration}second_epochs.csv'
feature_frame = pd.read_csv(filename_feature_frame, dtype={'subject': str})

# Drop missing values
feature_frame.dropna(axis=0, inplace=True)
feature_frame.dropna(axis=0, inplace=True)

# Show number of epochs per recording and vigilance class
print('Number of epochs per recording & class:')
print(feature_frame.groupby(['task_subject', 'vigilance_label']).size().reset_index(name='count'))

# update 'all_features'
all_features = list(feature_frame.drop(['epoch', 'task_subject'], axis=1).columns)

def aggregate_users(feature_frame):
    tasks_subjects = list(pd.unique(feature_frame.task_subject))
    X_all = None
    Y_all = None
    for task_subject in tasks_subjects:
        df_task_subject = feature_frame.loc[feature_frame.task_subject==task_subject]
        X = df_task_subject.drop(['epoch', 'vigilance_label', 'task_subject'], axis=1).astype("float32")
        Y = df_task_subject['vigilance_label'].astype("category")
        if X_all is None:
            X_all = X
        else:
            X_all = pd.concat([X_all, X], ignore_index=True)
        if Y_all is None:
            Y_all = Y
        else:
            Y_all = pd.concat([Y_all, Y], ignore_index=True)
        print("X_all", X_all.shape)

    return X_all, Y_all

def plot_confusion_matrix(cm, classes, input_features, acc, kappa,
                          normalize=False,
                          cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title('Confusion matrix')
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="black" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.title('Input features='+input_features+', accuracy='+str(round(acc, 2))+', Cohens Kappa='+str(round(kappa, 2)))
    plt.tight_layout()
    plt.show()

### Extract data
X_all, Y_all = aggregate_users(feature_frame)
X_all = X_all.to_numpy()
Y_all = Y_all.to_numpy()
print("data shape", X_all.shape, Y_all.shape)
print('Class distribution: %s' % Counter(Y_all))

### Model fitting and prediction

gridsearch_method = 'classic'  # 'classic' or 'Bayes'

scaler = MinMaxScaler()
kfold = KFold(n_splits=5, shuffle=True, random_state=42)
parameters = {'C': [0.1,1, 10, 100], 'gamma': [1,0.1,0.01,0.001],'kernel': ['linear', 'rbf', 'poly', 'sigmoid']}
parameters = {'kernel': ['rbf', 'poly', 'sigmoid'], 'C': [0.1,1, 10, 100]}
predictions = ["" for x in range(Y_all.shape[0])]
for ifold, (train, test) in enumerate(kfold.split(X_all, Y_all)):
    scaler.fit(X_all[train])
    scaler.transform(X_all[train])
    scaler.transform(X_all[test])
    if gridsearch_method=='classic':
        grid = GridSearchCV(SVC(), parameters, refit=True, verbose=3, scoring="f1_weighted", cv=5)
    elif gridsearch_method=='Bayes':
        grid = BayesSearchCV(estimator=SVC(), search_spaces=parameters, n_jobs=-1, cv=5)
    print('########## Performing grid-search on train set of fold', str(ifold+1), '...')
    grid.fit(X_all[train], Y_all[train])
    print('done')
    predictions_fold = grid.predict(X_all[test])
    for idx, pred in zip(test, predictions_fold):
        predictions[idx] = pred


# print classification report
print(classification_report(Y_all, predictions))

cnf_matrix = confusion_matrix(Y_all, predictions)

# Accuracy and Cohen's Kappa score
acc = accuracy_score(Y_all, predictions)
kappa = cohen_kappa_score(Y_all, predictions)
print(f'The accuracy score of the model is {acc:.4f}')
print(f'Cohens Kappa score: {kappa:.4f}')

# Plot normalized confusion matrix
fig_confmat = plt.figure()
plot_confusion_matrix(cnf_matrix, classes=grid.classes_, input_features=input_features, acc=acc, kappa=kappa, normalize=True)