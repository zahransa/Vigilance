#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 17 14:54:03 2022

Scripts that creates epochs from rating windows.

@author: nicolaiwolpert
"""

import numpy as np
import pandas as pd
import math
import os
import matplotlib
import matplotlib.pyplot as plt
import random
import seaborn as sns
import scipy
from scipy import stats
import mne

plt.close('all')

root = os.path.dirname(os.getcwd())
root = os.path.join(root, 'Vigilance')

raw_dir = os.path.join(root, 'Data_raw')
eeg_dir = os.path.join(raw_dir, 'EEG')
behavior_dir = os.path.join(raw_dir, 'Behavior')
data_work_path = root + '/Data_work/'

# Specify subjects for the different tasks with clean EEG & behavior
tasks_subjects = {'atc': ['01', '03', '04', '05', '08', '15', '21', '23', '24'],
                  'line_task_sim': ['02', '03', '04', '18', '25'],
                  'line_task_succ': ['02', '04', '05', '07'],
                  'oddball': ['04', '07']}

# Choose if to use EEG cleaned from artifacts or not
clean_EEG_artifacts = True

# Specify sample frequency
SFREQ = 250

TRIGGERS_CODES = {
    'TRIGGER_START_EXPERIMENT': 1,
    'TRIGGER_END_EXPERIMENT': 2,
    'TRIGGER_START_BLOCK': 10,
    'TRIGGER_END_BLOCK': 11,
    'TRIGGER_START_TRIAL': 20,
    'TRIGGER_END_TRIAL': 21,
    'TRIGGER_BUTTON_PRESS': 7
}

# Define the periods for the classes = data from the first vs. last <PERIODS_CLASSES> minutes
PERIODS_CLASSES = 10

# Specify length of epochs (in seconds)
epoch_duration = 5
epoch_duration_samples = epoch_duration * SFREQ

eeg_epochs_all = pd.DataFrame()
ecg_epochs_all = pd.DataFrame()
for task in tasks_subjects.keys():
    for subject_id in tasks_subjects[task]:

        print(f'##### Extracting epochs for task {task}, subject {subject_id}...')

        filepath_eeg_csv = data_work_path + f'{task}/EEG_raw_notch_cleaned_art/S' + subject_id + '/' + 'S' + subject_id + '_eeg_cleaned.csv'
        filepath_ecg_csv = data_work_path + f'{task}/ECG_raw_notch/S' + subject_id + '/' + 'S' + subject_id + '_ecg_notch.csv'
        eeg_csv = pd.read_csv(filepath_eeg_csv)
        ecg_csv = pd.read_csv(filepath_ecg_csv)

        # Extract data from the experimental block only (corresponds to last block triggers)
        # Oddball task has one training and four experimental blocks
        if task == 'oddball':
            ind_start_exp = list(eeg_csv.loc[eeg_csv.trigger==TRIGGERS_CODES["TRIGGER_START_BLOCK"]].index)[1]
            ind_end_exp = list(eeg_csv.loc[eeg_csv.trigger==TRIGGERS_CODES["TRIGGER_END_BLOCK"]].index)[-1]
        else:
            ind_start_exp = list(eeg_csv.loc[eeg_csv.trigger==TRIGGERS_CODES["TRIGGER_START_BLOCK"]].index)[-1]
            ind_end_exp = list(eeg_csv.loc[eeg_csv.trigger==TRIGGERS_CODES["TRIGGER_END_BLOCK"]].index)[-1]

        eeg_csv = eeg_csv.loc[ind_start_exp:ind_end_exp].reset_index(drop=True)
        ecg_csv = ecg_csv.loc[ind_start_exp:ind_end_exp].reset_index(drop=True)
        # Set all triggers to zero, they are not used here. New custom triggers will be inserted that mark the start of
        # each epoch.
        eeg_csv['trigger'] = 0
        ecg_csv['trigger'] = 0

        # Extract data from the beginning vs. end = first vs. last <PERIODS_CLASSES> minutes
        eeg_beginning = eeg_csv.loc[eeg_csv['timestamp']<=(eeg_csv['timestamp'][0] + PERIODS_CLASSES*60)]
        eeg_beginning.reset_index(inplace=True, drop=True)
        eeg_end = eeg_csv.loc[eeg_csv['timestamp']>=(eeg_csv['timestamp'].iloc[-1] - PERIODS_CLASSES*60)]
        eeg_end.reset_index(inplace=True, drop=True)

        ecg_beginning = ecg_csv.loc[eeg_csv['timestamp']<=(ecg_csv['timestamp'][0] + PERIODS_CLASSES*60)]
        ecg_beginning.reset_index(inplace=True, drop=True)
        ecg_end = ecg_csv.loc[ecg_csv['timestamp']>=(ecg_csv['timestamp'].iloc[-1] - PERIODS_CLASSES*60)]
        ecg_end.reset_index(inplace=True, drop=True)

        ### Extract epochs from the beginning = "high vigilance"
        nsamples_beginning = eeg_beginning.shape[0]

        eeg_epochs_high = pd.DataFrame(columns = ['task_subject', 'epoch'] + list(eeg_beginning.columns) + ['vigilance_label'])
        ecg_epochs_high = pd.DataFrame(columns = ['task_subject', 'epoch'] + list(ecg_beginning.columns) + ['vigilance_label'])
        idx_start_epoch = 0
        iepoch = 0
        while (idx_start_epoch + epoch_duration_samples) <= nsamples_beginning:
            iepoch += 1
            idx_end_epoch = idx_start_epoch + epoch_duration_samples

            eeg_epoch = eeg_beginning.loc[idx_start_epoch:(idx_end_epoch-1)]
            eeg_epoch['task_subject'] = task + '_' + subject_id
            eeg_epoch['epoch'] = iepoch
            eeg_epoch['vigilance_label'] = 'high'
            eeg_epochs_high = pd.concat([eeg_epochs_high, eeg_epoch])

            ecg_epoch = ecg_beginning.loc[idx_start_epoch:(idx_end_epoch-1)]
            ecg_epoch['task_subject'] = task + '_' + subject_id
            ecg_epoch['epoch'] = iepoch
            ecg_epoch['vigilance_label'] = 'high'
            ecg_epochs_high = pd.concat([ecg_epochs_high, ecg_epoch])

            iepoch += 1
            idx_start_epoch = idx_end_epoch + 1

        ### Extract epochs from the end = "low vigilance"
        nsamples_end = eeg_end.shape[0]

        eeg_epochs_low = pd.DataFrame(columns = ['task_subject', 'epoch'] + list(eeg_end.columns))
        ecg_epochs_low = pd.DataFrame(columns = ['task_subject', 'epoch'] + list(ecg_end.columns))
        idx_start_epoch = 0
        while (idx_start_epoch + epoch_duration_samples) <= nsamples_end:
            idx_end_epoch = idx_start_epoch + epoch_duration_samples

            eeg_epoch = eeg_beginning.loc[idx_start_epoch:(idx_end_epoch-1)]
            eeg_epoch['task_subject'] = task + '_' + subject_id
            eeg_epoch['epoch'] = iepoch
            eeg_epoch['vigilance_label'] = 'low'
            eeg_epochs_low = pd.concat([eeg_epochs_low, eeg_epoch])

            ecg_epoch = ecg_beginning.loc[idx_start_epoch:(idx_end_epoch-1)]
            ecg_epoch['task_subject'] = task + '_' + subject_id
            ecg_epoch['epoch'] = iepoch
            ecg_epoch['vigilance_label'] = 'low'
            ecg_epochs_low = pd.concat([ecg_epochs_low, ecg_epoch])

            iepoch += 1
            idx_start_epoch = idx_end_epoch + 1

        eeg_epochs_subject = pd.concat([eeg_epochs_high, eeg_epochs_low])
        ecg_epochs_subject = pd.concat([ecg_epochs_high, ecg_epochs_low])

        eeg_epochs_all = pd.concat([eeg_epochs_all, eeg_epochs_subject])
        ecg_epochs_all = pd.concat([ecg_epochs_all, ecg_epochs_subject])

eeg_epochs_all.to_csv(data_work_path + f'ML/epochs/eeg_epochs_all_{epoch_duration}_seconds.csv')
ecg_epochs_all.to_csv(data_work_path + f'ML/epochs/ecg_epochs_all_{epoch_duration}_seconds.csv')
