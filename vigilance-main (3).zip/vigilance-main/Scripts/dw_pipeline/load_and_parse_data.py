"""
Created on Thu Sep 22 2023

@author: dwobrock
"""
import mne
from mne.channels import DigMontage
import pandas as pd
import numpy as np
from create_labels import calculate_labels_from_file


def dress_inventory_of_available_data(base_path: str, subjects_to_keep: list = None, tasks_to_keep: list = None) -> list:
    """
    Function to return a list of all available data present as the base path location

    :param base_path: str, path to the root of the data folder
    :param subjects_to_keep: list of str, list of participants whose data is to be analyzed
    :param tasks_to_keep: list of str, list of tasks of which data is to be analyzed
    :return: list of 3 list, list of paths to the data, list of participants associated, list of tasks
    """

    all_tasks = []
    all_subjects = []
    all_paths = []

    import os
    # Iterate through the two levels of the directory to find the necessary data
    for folder_element in os.listdir(base_path):
        if os.path.isdir(os.path.join(base_path, folder_element)):
            if os.path.isdir(os.path.join(base_path, folder_element, "EEG")):
                for sub_folder_element in os.listdir(os.path.join(base_path, folder_element, "EEG")):
                    if os.path.isdir(os.path.join(base_path, folder_element, "EEG", sub_folder_element)):
                        for sub_sub_folder_element in os.listdir(os.path.join(base_path, folder_element,
                                                                              "EEG", sub_folder_element)):
                            if sub_sub_folder_element.lower().endswith(".csv"):
                                all_tasks.append(folder_element)
                                all_subjects.append(sub_folder_element)
                                all_paths.append(os.path.join(base_path, folder_element, "EEG", sub_folder_element,
                                                              sub_sub_folder_element))

    # verify that all the data paths correspond to subjects of
    keep_list = [True] * len(all_paths)
    if subjects_to_keep is not None:
        for counter in range(len(all_subjects)):
            if not(all_subjects[counter] in subjects_to_keep):
                keep_list[counter] = False

    if tasks_to_keep is not None:
        for counter in range(len(all_tasks)):
            if not(all_tasks[counter] in tasks_to_keep):
                keep_list[counter] = False

    # adjust created lists to remove non whitelisted data
    from itertools import compress
    all_tasks = list(compress(all_tasks, keep_list))
    all_subjects = list(compress(all_subjects, keep_list))
    all_paths = list(compress(all_paths, keep_list))

    return [all_paths, all_tasks, all_subjects]


def load_data_from_file_to_mne(path_to_file: str,
                               mne_montage: DigMontage = mne.channels.make_standard_montage("standard_1020"),
                               keep_ecg=False) -> mne.io.RawArray:
    """
    Function aimed at loading the data from a specific path and arange it into an mne raw array format
    :param path_to_file: str, path to the csv file containing the raw data
    :param mne_montage: mne.channels.DigMontage, Used montage of electrode positions during experiment
    :param keep_ecg: bool, flag if the ecg channel should be kept in the final mne array or not
    :return: mne_raw_data:  mne.io.RawArray, the ready to use mne array filled and properly labeled
    """
    # read file content
    data_pandas_format = pd.read_csv(path_to_file)

    # rename channels in accordance with noted changes
    if "P4" in data_pandas_format.columns:
        data_pandas_format.rename(columns={"O1": "Pz", "O2": "O1", "Pz": "O2", "CPz": "ECG",
                                           "P3": "F3", "P4": "F4", "F3": "Fp1", "F4": "Fp2"}, inplace=True)
    else:
        data_pandas_format.rename(columns={"Fz": "ECG"}, inplace=True)

    # calculate sampling rate (should be done via hard-coding the value)
    sampling_rate = np.round(1/np.median(np.diff(data_pandas_format.loc[:, "timestamp"])))

    # extract the channels corresponding to the interesting data
    present_channels = []
    channel_types = []
    for column_name in data_pandas_format.columns:
        if column_name in mne_montage.ch_names:
            present_channels.append(column_name)
            channel_types.append('eeg')
        elif keep_ecg and column_name == "ECG":
            present_channels.append(column_name)
            channel_types.append('ecg')

    # create mne info element
    mne_info = mne.create_info(ch_names=present_channels, sfreq=sampling_rate, ch_types=channel_types)
    mne_info.set_montage(mne_montage)

    # read kept signal data from file
    data_numpy_format = np.transpose(data_pandas_format.loc[:, present_channels].to_numpy())

    # combine information into mne element
    mne_raw_data = mne.io.RawArray(data_numpy_format, mne_info)

    return mne_raw_data


def load_bis_labels_from_file(path_to_file: str, sampling_rate: int, window_size: int, window_step: int, adjusted_formula=True, upper_response_time_limit=2):
    """
    Function aimed at extracting the Balanced integrated score labels from the trigger file
    :param path_to_file: str, path to the csv file containing a column labeled "trigger" and one labeled "timestamp"
    :param sampling_rate: int, sampling rate of the other biosignal
    :param window_size: int, length of windows, in seconds, on which data will be gathered to calculate the BIS
    :param window_step: int, step size for the moving window, in seconds
    :param adjusted_formula:  bool, flag if the score should be calculated differently ('+1' in the denominator)
    :param upper_response_time_limit: int, maximal duration of inter stimulus interval or maximum time to give an input
    :return: padded_bsi_scores: np.ndarray, array as long as the eeg recording with the BIS label at each moment in time
    :return: session_onset_time_ids: np.ndarray, array containing the location of the start and end of session blocks within the recording
    """

    # read file content
    data_pandas_format = pd.read_csv(path_to_file)

    # conversion to obtain triggers and timestamps inside the dataframe
    work_data = data_pandas_format.copy()
    trigger_data = work_data.dropna(subset="trigger")
    active_triggers_ids = np.squeeze(np.argwhere(np.logical_not(np.isnan(data_pandas_format.loc[:, "trigger"]))))
    trigger_timestamps = trigger_data.loc[:, "timestamp"].to_numpy()
    trigger_values = trigger_data.loc[:, "trigger"].to_numpy()

    # extract location of stimuli onsets and button presses
    stim_onset_ids = np.where((trigger_values == 40) | (trigger_values == 30) | (trigger_values == 50))[0]
    button_ids = np.where(trigger_values == 7)[0]

    # session start and end points
    session_onset_ids = np.where((trigger_values == 10) | (trigger_values == 11))[0]
    session_onset_time_ids = np.int_(np.round(trigger_timestamps[session_onset_ids] * sampling_rate))

    # transform into real time
    button_press_times = trigger_timestamps[button_ids] * sampling_rate
    stim_onset_times = trigger_timestamps[stim_onset_ids] * sampling_rate

    # selection is correct if, following the appearence or disappearence of a target stim, there is a button press
    # selection is correct if, following the appearence or disappearence of a non target stim, there is no button press
    previously_correct = 1 * (((trigger_values[stim_onset_ids] == 30) & ((trigger_values[stim_onset_ids + 1] == 7) | (trigger_values[stim_onset_ids + 2] == 7))) |
                         ((trigger_values[stim_onset_ids] == 50) & ((trigger_values[stim_onset_ids + 1] != 7) & (trigger_values[stim_onset_ids + 2] != 7))) |
                         ((trigger_values[stim_onset_ids] == 40) & ((trigger_values[stim_onset_ids + 1] != 7) & (trigger_values[stim_onset_ids + 2] != 7))))

    # Calculate the response time to the closest previous stimulus
    response_time = -1 * np.ones((button_press_times.size,))
    import math
    for counter in range(response_time.size):
        time_differences = -1 * (stim_onset_times - button_press_times[counter])
        time_differences[time_differences < 0] = math.inf
        response_time[counter] = np.min(time_differences)

    response_time /= (upper_response_time_limit * sampling_rate)

    # general values for scores
    general_pc = np.mean(previously_correct)
    general_rt = np.mean(response_time)

    # calculate BIS scores
    window_size = window_size * sampling_rate
    window_step = window_step * sampling_rate

    starting_points = np.arange(0, data_pandas_format.shape[0] - window_size, window_step, dtype=int)
    ending_points = starting_points + window_size
    local_bis_scores = np.zeros((starting_points.size,))

    for i in range(starting_points.size):
        start_point = starting_points[i]
        end_point = ending_points[i]

        locations_id_button = np.where((button_press_times < end_point) & (button_press_times >= start_point))[0]
        locations_id_stims = np.where((stim_onset_times < end_point) & (stim_onset_times >= start_point))[0]
        if (locations_id_button.size <= 1) | (locations_id_stims.size <= 1):
            continue
        local_prev_correct = previously_correct[locations_id_stims]
        local_resp_time = response_time[locations_id_button]
        if adjusted_formula:
            z_pc = (np.mean(local_prev_correct) - general_pc) / (1 + np.std(local_prev_correct))
            z_rt = (np.mean(local_resp_time) - general_rt) / (1 + np.std(local_resp_time))
        else:
            z_pc = (np.mean(local_prev_correct) - general_pc) / np.std(local_prev_correct)
            z_rt = (np.mean(local_resp_time) - general_rt) / np.std(local_resp_time)
        local_bis_scores[i] = z_pc - z_rt

    # padding the data to the entirety of the recording
    tmp_mat = np.zeros((data_pandas_format.shape[0],))
    tmp_mat[np.int_(ending_points)] = 1
    idx = np.int_(tmp_mat.cumsum(-1)-1)
    padded_bsi_scores = local_bis_scores[idx]

    return padded_bsi_scores, session_onset_time_ids


def load_labels_from_file(path_to_file: str, sampling_rate: int, window_size: int, window_step: int, upper_response_time_limit=2, method='bis_adj'):
    """
    Function aimed at extracting the Balanced integrated score labels from the trigger file
    :param path_to_file: str, path to the csv file containing a column labeled "trigger" and one labeled "timestamp"
    :param sampling_rate: int, sampling rate of the other biosignal
    :param window_size: int, length of windows, in seconds, on which data will be gathered to calculate the BIS
    :param window_step: int, step size for the moving window, in seconds
    :param adjusted_formula:  bool, flag if the score should be calculated differently ('+1' in the denominator)
    :param upper_response_time_limit: int, maximal duration of inter stimulus interval or maximum time to give an input
    :param method: str, from ['bsi_adj','bsi','rt','pc','ies','rcs','lisas'], method to calculate the labels from
    :return: padded_scores: np.ndarray, array as long as the eeg recording with the BIS label at each moment in time
    :return: session_onset_time_ids: np.ndarray, array containing the location of the start and end of session blocks within the recording
    """
    padded_scores, session_onset_time_ids = calculate_labels_from_file(path_to_file, sampling_rate, window_size,
                                                                       window_step,
                                                                       method, upper_response_time_limit)
    return padded_scores, session_onset_time_ids
