"""
Created on Thu Sep 22 2023

@author: dwobrock
"""
import mne.io
import numpy as np


def perform_initial_filter(mne_data: mne.io.RawArray, bandpass_params: list = None, notch_params: list = None):
    """
    Perform a filtering of the data. Both a notch and bandpass are performed, in that order
    :param mne_data: mne.io.RawArray, mne array containing the data from the recording
    :param bandpass_params: list, list of two floats establishing the upperandower bound of the bandpass filter
    :param notch_params: list, list of floats of the frequencies to remove from the main recording
    :return: work_data: mne.io.Raw, mne array containing the filtered data
    """

    # prepare environment
    work_data = mne_data.copy()
    if bandpass_params is None:
        bandpass_params = [0.1, 50]
    if notch_params is None:
        notch_params = [50, 100]

    # Apply filters
    work_data.notch_filter(notch_params, notch_widths=2)
    work_data.filter(np.min(bandpass_params), np.max(bandpass_params))

    return work_data


def apply_burst_correction(mne_data: mne.io.RawArray, correction_type="euclid", window_size=1):
    """
    Applies different types of burst correction on the data, so far only the ASR algorithm is implemented
    :param mne_data: mne.io.Raw, mne array containing the artifactual data
    :param correction_type: str ("euclid","riemann","orica"), name of the method to apply. So far only "euclid" works.
    :param window_size: float, size of windows to segment the data as
    :return: work_data: mne.io.Rawv, mne array containing the burst cleaned data
    """

    import asrpy
    work_data = mne_data.copy()
    if correction_type == "euclid":
        asr = asrpy.ASR(work_data.info['sfreq'], cutoff=20)
        asr.fit(work_data)
        mne_rawdata_clean = asr.transform(work_data)
        return mne_rawdata_clean

    elif correction_type == "riemann":
        from timeflux_rasr.estimators.rasr import RASR
        import skimage
        import asrpy
        riemann_asr = RASR()

        numpy_data = work_data.get_data().T
        win_size = int(np.round(window_size*work_data.info['sfreq']))
        clean_asr_data, _ = asrpy.clean_windows(numpy_data.T, work_data.info['sfreq'])

        windowed_data = np.squeeze(skimage.util.view_as_windows(numpy_data, [win_size, numpy_data.shape[1]], step=win_size)).transpose((0, 1, 2))
        clean_windowed_data = np.squeeze(skimage.util.view_as_windows(clean_asr_data.T, [win_size, clean_asr_data.shape[0]], step=win_size)).transpose((0, 1, 2))
        # clean_data = RASR().fit_transform(windowed_data)
        riemann_asr.fit(clean_windowed_data)
        clean_data2 = riemann_asr.transform(windowed_data)
        return_data = clean_data2.transpose((2, 0, 1)).reshape(numpy_data.shape[1], -1)
        '''
        for i in range(50):
            plt.figure()
            plt.plot(np.squeeze(numpy_data[(i*win_size):((i+1)*win_size),0]), linewidth=4)
            plt.plot(np.squeeze(windowed_data[i, :, 0]), linewidth=2)
            plt.plot(np.squeeze(clean_data[i, :, 0]))
            plt.plot(np.squeeze(clean_data2[i, :, 0]))
            plt.show()
        '''
        mne_rawdata_clean = mne.io.RawArray(return_data, work_data.info)
        return mne_rawdata_clean
    elif correction_type == "orica":
        print("Orica not implemented yet")
        return work_data
    else:
        print("Method not supported")
        return work_data


def epoching_data(mne_data: mne.io.RawArray, cont_labels: np.ndarray, i_window_size: int = 1, i_window_step: int = 5, use_only_eeg=True):
    """
    Functions to segment the data and its labels using a moving window ti create smaller segments
    :param mne_data: mne.io.RawArray, mne array containing the data to put into windows
    :param cont_labels: np.ndarray, continous array of labels associated with each time point during the recording
    :param i_window_size: int, size of the windows to return (in seconds)
    :param i_window_step: int, step between windows (in seconds)
    :param use_only_eeg: bool, flag to only use the eeg data present in the recording.
    :return: windowed_data: np.ndarray, 3 dimensional array corresponding to the obtained windows of usable data
    :return: windowed_labels: np.ndarray, 2 dimensional array corresponding to the obtained windows of labels
    """

    import skimage
    window_size = int(mne_data.info['sfreq'] * i_window_size)
    step_size = int(mne_data.info['sfreq'] * i_window_step)
    if use_only_eeg:
        data = mne_data.get_data('eeg').T
    else:
        data = mne_data.get_data().T
    windowed_data = np.squeeze(skimage.util.view_as_windows(data, [window_size, data.shape[1]], step=step_size)).transpose((0, 2, 1))
    windowed_labels = np.mean(np.squeeze(skimage.util.view_as_windows(cont_labels, [window_size], step=step_size)), axis=1)

    return [windowed_data, windowed_labels]


def extract_data_segment(mne_data: mne.io.RawArray, labels: np.ndarray, start_id: int, end_id: int):
    """
    Crop segment of data in the usable data and the labels according to a start and end point
    :param mne_data: mne.io.RawArray, usable data in mne array form to crop
    :param labels: np.ndarray, labeled data to crop
    :param start_id: int, start position of the crop (in ids)
    :param end_id: int, end position of the crop (in ids)
    :return: crop_mne_data: mne.io.RawArray, mne array containing the cropped data
    :return: crop_label: np.ndarray, array containing the cropped data
    """

    work_data = mne_data.copy()
    cropped_data = work_data.get_data()[:, start_id:end_id]
    crop_mne_data = mne.io.RawArray(cropped_data, work_data.info)

    work_label = labels.copy()
    crop_label = work_label[start_id:end_id]

    return crop_mne_data, crop_label


def extract_frequencies(windowed_data: np.ndarray, sampling_rate: int, freq_bins=None, normalization=False, added_amp=False):
    """
    Obtained the frequencies from the inputed data, binned into bands if wantec
    :param windowed_data: np.ndarray, 3 dimensional data containing the windows of the data to transform
    :param sampling_rate: int, sampling rate of the data
    :param freq_bins: list, list of float corresponding to the bin limits to extract
    :param normalization: bool, flag if the frequencies should be divided by their sum
    :param added_amp: bool, flag if another value informing about the amplitude should be appended on normalized data
    :return: return_freq_mat, np.ndarray, 3d array containing the resulting frequency data
    """

    work_data = windowed_data.copy()
    present_frequencies = np.fft.rfftfreq(windowed_data.shape[-1], d=1/sampling_rate)

    freq_mat = np.abs(np.fft.rfft(work_data, axis=-1))

    if freq_bins is not None:
        freq_bins.sort()
        return_freq_mat = np.zeros(np.concatenate((freq_mat.shape[:-1], np.asarray([len(freq_bins)-1]))))
        for bin_index in range(len(freq_bins)-1):
            current_ids = np.where((present_frequencies >= freq_bins[bin_index]) &
                                   (present_frequencies < freq_bins[bin_index+1]))[0]
            if len(freq_mat.shape) == 2:
                return_freq_mat[:, bin_index] = np.mean(freq_mat[:, current_ids], axis=1)
            elif len(freq_mat.shape) == 3:
                return_freq_mat[:, :, bin_index] = np.squeeze(np.mean(freq_mat[:, :, current_ids], axis=2))
            else:
                print("Non applicable amount of dimensions")
                return freq_mat
    else:
        return_freq_mat = freq_mat

    if normalization:
        # perform division by sum of all elements
        print("Performing normalization on frequencies")
        agg_value = np.sum(return_freq_mat, axis=-1, keepdims=True)
        agg_value_copy = agg_value.copy()
        agg_value_copy.repeat(return_freq_mat.shape[-1], -1)
        return_freq_mat = np.divide(return_freq_mat, agg_value_copy)

        if added_amp:
            # add additional dimension representing the amplitude of the now normalized frequencies
            value_agg = agg_value.flatten()
            return_freq_mat = np.concatenate((return_freq_mat, (agg_value-np.min(value_agg))/(np.max(value_agg)-np.min(value_agg))), axis=-1)

    return return_freq_mat


def perform_pca(raw_data: np.ndarray, nb_dimensions=0.999):
    """
    Performs the PCA onto the inputed data
    :param raw_data: np.ndarray, the data to transform
    :param nb_dimensions: int or float, number of dimensions or percentage of variance to be present in the PCA
    :return: component_data: np.ndarray, the pca component dataz
    """

    from sklearn.decomposition import PCA

    work_data = raw_data.copy()
    if len(raw_data.shape) > 2:
        input_mat = np.reshape(work_data, (work_data.shape[0], -1))
    else:
        input_mat = work_data

    component_data = PCA(n_components=nb_dimensions, svd_solver='full').fit_transform(input_mat)
    return component_data


def calculate_comodulogram(mne_data: np.ndarray, sampling_rate: int, low_fq_range=np.linspace(1, 12, 50),
                           low_fq_width=1.0, method=None, do_plot=False, title=None):
    """
    Calculates the comodulogram on the data
    :param mne_data: np.ndarray, data to transform
    :param sampling_rate: int, sampling rate of the data
    :param low_fq_range: np.ndarray, frequencies to examine
    :param low_fq_width: float, parameter
    :param method: str, type of method to use
    :param do_plot: bool, flag to plot the results
    :param title: str,title of the plot
    :return: results: list, list of Comodulogram of the data
    """

    from pactools import Comodulogram, REFERENCES
    methods = [
            'ozkurt', 'canolty', 'tort', 'penny', 'vanwijk', 'duprelatour', 'colgin',
            'sigl', 'bispectrum'
        ]
    work_data = mne_data.copy()
    result_list = []

    if method is None:
        method = methods
    else:
        method = [method]

    if do_plot:
        import matplotlib.pyplot as plt
        n_lines = int(np.ceil(np.sqrt(len(method))))
        n_columns = int(np.ceil(len(methods) / float(n_lines)))
        fig, axs = plt.subplots(
            n_lines, n_columns, figsize=(4 * n_columns, 3 * n_lines))
        axs = axs.ravel()

    for current_method_id in range(len(method)):
        current_method = method[current_method_id]
        estimator = Comodulogram(fs=sampling_rate, low_fq_range=low_fq_range, low_fq_width=low_fq_width,
                                 method=current_method, progress_bar=False)
        estimator.fit(work_data)
        result_list.append(np.asarray(estimator.comod_))

        if do_plot:
            import matplotlib.pyplot as plt
            estimator.plot(titles=[REFERENCES[current_method]], axs=[axs[current_method_id]])
            plt.suptitle(title)

    return result_list


def calculate_all_comodulograms(mne_data: np.ndarray, sampling_rate: int, low_fq_range=np.linspace(1, 12, 50),
                                  low_fq_width=1.0, method='ozkurt'):
    """
    Calculates the comodulograms on the whole data
    :param mne_data: np.ndarray, data to transform
    :param sampling_rate: int, sampling rate of the data
    :param low_fq_range: np.ndarray, frequencies to examine
    :param low_fq_width: float, parameter
    :param method: str, type of method to use (should not be None or empty)
    :return: return_array: np.ndarray, numpy array of Comodulograms of the data
    """
    if method is None:
        print("Please specify a method")
        return 0

    from pactools import Comodulogram
    estimator = Comodulogram(fs=sampling_rate, low_fq_range=low_fq_range, low_fq_width=low_fq_width,
                             method=method, progress_bar=False)

    nb_trials, nb_channels, nb_times = mne_data.shape
    for trial_id in range(nb_trials):
        print(trial_id)
        for channel_id in range(nb_channels):
            current_samples = np.squeeze(mne_data[trial_id, channel_id, :])
            estimator.fit(current_samples)
            result_array = np.asarray(estimator.comod_)
            try:
                return_array[trial_id, channel_id, :, :] = result_array
            except NameError:
                return_array = np.zeros((nb_trials, nb_channels, low_fq_range.size, result_array.shape[1]))
                return_array[trial_id, channel_id, :, :] = result_array

    print("Finish")
    return return_array
