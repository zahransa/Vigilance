#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 2023

@author: dwobrock
"""

import numpy as np
import matplotlib.pyplot as plt


def highdim_plot(data_array: np.ndarray, labels: np.ndarray, title=""):
    """
    Plots high dimensional data using two types of projections:
    - t-stochastic neighbourhood embedding (t-SNE)
    - Uniform Manifold Approximation and Projection for Dimension Reduction (UMAP)
    Inputs :
        - data_array : ndarray (nbChannels, nbSamples), data array to plot
        - labels : ndarray (nbSamples,), labels to color each point with
        - title : str, title to give the resulting plot
    """

    from sklearn.manifold import TSNE
    from umap import UMAP

    # Calculate projections into lower spaces
    tsne = TSNE(n_components=2, verbose=1, perplexity=40, n_iter=300)
    tsne_results = tsne.fit_transform(data_array)
    umap_results = UMAP().fit_transform(data_array)

    fig, (ax1, ax2) = plt.subplots(1, 2)
    plt.suptitle(title)
    plt.set_cmap('jet')
    ax1.scatter(tsne_results[:, 0], tsne_results[:, 1], c=labels, marker='.')
    ax1.set_title("TSNE Projection")
    ax1.set_xlabel("TSNE dim 1")
    ax1.set_ylabel("TSNE dim 2")

    ax2.scatter(umap_results[:, 0], umap_results[:, 1], c=labels, marker='.')
    ax2.set_title("UMAP Projection")
    plt.set_cmap('jet')
    ax2.set_xlabel("UMAP dim 1")
    ax2.set_ylabel("UMAP dim 2")
    plt.show()


def pca_space_plot(data_array: np.ndarray, color_label: np.ndarray, title=""):
    """
    Plots high dimensional data into the first two components of the principal component space
    Inputs :
        - data_array : ndarray (nbChannels, nbSamples), data array to plot
        - color_label : ndarray (nbSamples,), labels coloring each point in the final plot
        - title : str, title to give the resulting plot
    """
    from sklearn.decomposition import PCA
    pca = PCA(n_components=2, svd_solver='full')
    proj_data = pca.fit_transform(data_array)

    plt.figure()
    plt.scatter(proj_data[:, 0], proj_data[:, 1], c=color_label, marker='.')
    plt.title(title)
    plt.xlabel('PCA dim1')
    plt.ylabel('PCA dim2')
    plt.show()


def lda_space_plot(data_array: np.ndarray, class_labels: np.ndarray, color_label: np.ndarray, title=""):
    """
    Plots high dimensional data into a linear discriminant analysis space
    Inputs :
        - data_array : ndarray (nbChannels, nbSamples), data array to plot
        - class_labels : ndarray (nbSamples,), labels allowing the classification of the data
        - color_label : ndarray (nbSamples,), labels coloring each point in the final plot
        - title : str, title to give the resulting plot
    """

    # perform LDA
    height, width = data_array.shape
    unique_classes = np.unique(class_labels)
    num_classes = len(unique_classes)

    scatter_t = np.cov(data_array.T)*(height - 1)
    scatter_w = 0
    for i in range(num_classes):
        class_items = np.flatnonzero(class_labels == unique_classes[i])
        scatter_w = scatter_w + np.cov(data_array[class_items].T) * (len(class_items)-1)

    scatter_b = scatter_t - scatter_w
    _, eig_vectors = np.linalg.eigh(np.linalg.pinv(scatter_w).dot(scatter_b))
    pc = data_array.dot(eig_vectors[:, ::-1][:, :2])

    plt.figure()
    plt.scatter(pc[:, 0], pc[:, 1], c=color_label)
    plt.title(title)
    plt.xlabel('LDA dim1')
    plt.ylabel('LDA dim2')
    plt.show()

    # Sklearn method
    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    lda = LinearDiscriminantAnalysis()
    proj_data_array = lda.fit_transform(data_array, class_labels)

    plt.figure()
    if len(proj_data_array.shape) > 1 and proj_data_array.shape[1] > 1:
        plt.scatter(proj_data_array[:, 0], proj_data_array[:, 1], c=color_label, marker='.')
    else:
        other_vector = np.random.randn(data_array.shape[1])
        other_vector -= other_vector.dot(lda.scalings_) * other_vector
        other_vector /= np.linalg.norm(other_vector)
        other_dim = np.dot(data_array, other_vector)

        plt.scatter(proj_data_array[:, 0], other_dim, c=color_label, marker='.')
    plt.title(title)
    plt.xlabel('LDA dim1')
    plt.ylabel('LDA dim2')
    plt.show()


def eeg_movie(data_array: np.ndarray, time_array: np.ndarray, electrodes: list, title="", subtitles: list = None, frame_rate=30, save_location="./test.mp4", smoothing=True, general_extrema=True):
    """
    Plots (and/or saves) a video showing topological activity over time of a given activity:
    Inputs :
        - data_array : ndarray (nbChannels, nbSamples (, nbCases)), data array to plot
        - time_array : ndarray (nbSamples,), timestamps associated with each sample
        - electrodes : List of str, name of electrodes contained within the topoplot
        - title : str, title to give to the video
        - subtitles : List of str, list of names that will be displayed over individual graphs
        - frame_rate : int, speed at which the video will be replayed
        - save_location : str, path where the video will be saved (has to be .mp4)
        - smoothing : smoothing of the function to plot over time to make changes less artifact dependant
        - general_extrema : color scaling determined over all cases or just over individual cas
    """

    import mne
    info = mne.create_info(ch_names=electrodes, sfreq=1, ch_types=['eeg'] * len(electrodes))
    info.set_montage("standard_1020")

    if len(data_array.shape) == 2:
        data_array = np.expand_dims(data_array, axis=2)

    import math
    nb_plots = data_array.shape[2]
    nb_sub_plot_x = math.ceil(math.sqrt(nb_plots))
    nb_sub_plot_y = math.ceil(nb_plots/nb_sub_plot_x)

    fig, axes = plt.subplots(ncols=nb_sub_plot_x, nrows=nb_sub_plot_y)

    def data_gen():
        nonlocal data_array
        data = data_array.copy()

        if smoothing:
            import scipy.signal as ssi
            # applying Savitzky-Golay filter for smoothing signal
            data = ssi.savgol_filter(data, 10, 3, axis=0)

        if general_extrema:
            vmax = np.repeat(np.max(data.flatten()), data.shape[2])
            vmin = np.repeat(np.min(data.flatten()), data.shape[2])
        else:
            vmax = np.squeeze(np.max(data, axis=0))
            vmin = np.squeeze(np.min(data, axis=0))

        time_counter = 0
        while time_counter < data.shape[0]:
            return_list = []
            for type_counter in range(data.shape[2]):
                data_element = np.squeeze(data[time_counter, :, type_counter])
                return_list.append(data_element)
            time_counter += 1
            yield return_list, vmax, vmin, time_counter

    def run(input_list):

        nonlocal info, electrodes, axes, nb_sub_plot_x, nb_sub_plot_y, subtitles
        data_list, vmax, vmin, time_counter = input_list

        fig_counter = 0
        for axe_row in axes:
            for axe in axe_row:
                if fig_counter < nb_plots:
                    mne.viz.plot_topomap(data_list[fig_counter], info, names=electrodes, axes=axe, show=False,
                                         vlim=(vmin[fig_counter], vmax[fig_counter]))
                    axe.set_title(subtitles[fig_counter])
                    fig_counter += 1
                else:
                    axe.axis('off')
        plt.suptitle(title + "--" + str(time_array[time_counter])+" s")

    import matplotlib.animation as animation
    ani = animation.FuncAnimation(fig, run, data_gen, blit=True, interval=10, repeat=False)

    if save_location is not None:
        from matplotlib.animation import FFMpegWriter
        writer_video = animation.FFMpegWriter(fps=frame_rate)
        ani.save(save_location, writer=writer_video)

    plt.show()

    '''
    from matplotlib.animation import FFMpegWriter
    metadata = dict(title="Movie", artist="MaA")
    writer = FFMpegWriter(fps=frame_rate, metadata=metadata)
    if len(data_array.shape) == 2:
        # TODO Complete singular element topoplot
        mne_element = mne.io.RawArray(data_array, info)
        vmax = np.max(data_array.flatten())
        vmin = np.min(data_array.flatten())
        pass

    # three-dimensional array
    else:

        nb_plots = data_array.shape[2]
        nb_sub_plot_x = math.ceil(math.sqrt(nb_plots))
        nb_sub_plot_y = math.ceil(nb_plots/nb_sub_plot_x)



        tmp_calc = np.reshape(data_array.transpose((2, 0, 1)), (data_array.shape[2], -1))
        vmax = np.max(tmp_calc.flatten())
        vmin = np.min(tmp_calc.flatten())

        if smoothing:
            import scipy.signal as ssi
            # applying Savitzky-Golay filter for smoothing signal
            data_array = ssi.savgol_filter(data_array, 10, 3, axis=0)

        with writer.saving(fig, save_location, 100):
            counter = 0
            while counter < data_array.shape[0]:

                fig_counter = 0
                for axe_row in axes:
                    for axe in axe_row:
                        if fig_counter < nb_plots:
                            sub_array = np.squeeze(data_array[:, :, fig_counter]).T
                            mne.viz.plot_topomap(sub_array[:, counter], info, names=electrodes, axes=axe, show=False, vlim=(vmin, vmax))
                            axe.set_title(subtitles[fig_counter])
                            fig_counter += 1
                        else:
                            axe.axis('off')
                counter += 1
                plt.suptitle(title+"==" + str(time_array[counter])+" s")
                writer.grab_frame()
                for axe_row in axes:
                    for axe in axe_row:
                        axe.clear()
    '''
    plt.clf()
