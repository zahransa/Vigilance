"""
Created on Thu Sep 22 2023

@author: dwobrock
"""

import mne
import numpy as np
import sklearn.pipeline

from load_and_parse_data import dress_inventory_of_available_data, load_data_from_file_to_mne,  load_labels_from_file
from prepare_data import perform_initial_filter, apply_burst_correction, epoching_data, perform_pca, \
    extract_frequencies, extract_data_segment, calculate_comodulogram

import matplotlib.pyplot as plt

DATA_FOLDER = "C:\\Users\\dwobrock\\Documents\\DataSets\\Vigilance\\"
SAVE_LOCATION = 'C:/Users/dwobrock/Documents/WorkspaceVSC/tres_my_excel_file1.xlsx'
show_graphs = False

# time information in seconds
label_calc_window_size = 150
label_calc_window_step = 30

epoch_window_size = 5
epoch_window_step = 4

use_adjusted_BIS_score = True
do_comodulogram = False
temporal_labeling = True
response_time_limit_in_seconds = 2
freq_bins = [0.5, 4, 8, 13, 35, 1000]

do_multi_class = False
type_of_score = 'bis_adj'

number_pca_components = 0.999
burst_correction_method = "euclid"

def process_pipeline_vigilance():

    # Step 0 : make inventory of available data
    participants_white_list = None
    tasks_white_list = ['atc', 'line_task_succ', 'line_task_sim']
    [all_paths, all_tasks, all_participants] = dress_inventory_of_available_data(DATA_FOLDER,
                                                                                 participants_white_list,
                                                                                 tasks_white_list)
    if show_graphs:
        print(all_paths)
        print(all_tasks)
        print(all_participants)


    complete_data = np.empty((0, 4382))
    complete_labels = np.empty((0,))
    complete_run_id = np.empty((0,))

    save_data_matrix = np.zeros((len(all_participants), 2 + 15 * 5))

    # Step 1 : go through all chosen recordings
    for path_id in range(len(all_paths)):

        path = all_paths[path_id]
        participant = all_participants[path_id]
        task = all_tasks[path_id]
        print(path)

        save_data_matrix[path_id, 0] = int(participant)
        if task == "atc":
            save_data_matrix[path_id, 1] = 1
        elif task == "line_task_sim":
            save_data_matrix[path_id, 1] = 2
        elif task == "line_task_succ":
            save_data_matrix[path_id, 1] = 3
        elif task == "oddball":
            save_data_matrix[path_id, 1] = 4
        element_counter = 2

        # Step 2 : extract the data in mne format
        mne_raw_data = load_data_from_file_to_mne(path, mne.channels.make_standard_montage("standard_1020"))
        sampling_frequency = mne_raw_data.info['sfreq']

        if show_graphs:
            print(sampling_frequency)
            mne_raw_data.plot()
            plt.show()

        # Step 3 : extract the labels associated with the data
        # vigilance score labeling
        bsi_labels, session_start_stops = load_labels_from_file(path, sampling_frequency, label_calc_window_size,
                                                                label_calc_window_step, response_time_limit_in_seconds,
                                                                method=type_of_score)

        # temporal labeling
        if temporal_labeling:
            bsi_labels = np.linspace(0, 1, bsi_labels.size)

        # random labeling
        # bsi_labels = np.random.rand(bsi_labels.shape[0])

        print(session_start_stops)

        if show_graphs:
            plt.figure()
            plt.plot(bsi_labels)
            plt.show()

        # Step 4 : crop the data corresponding the actual experiment (not the training phase)
        try:
            mne_raw_data, bsi_labels = extract_data_segment(mne_raw_data, bsi_labels, session_start_stops[2], session_start_stops[3])
        except:
            print("No extraction possible")

        # Step 5 : filter the data
        mne_raw_data_filtered = perform_initial_filter(mne_raw_data, [0.1, 60], [50, 100])

        # Step 6 : clean data with ASR/ burst correction
        mne_raw_data_clean = apply_burst_correction(mne_raw_data_filtered, correction_type=burst_correction_method)

        # Step 7 : epoch data
        [window_data, window_labels] = epoching_data(mne_raw_data_clean, bsi_labels, epoch_window_size, epoch_window_step, use_only_eeg=True)

        # Step 8b : comodulogram extraction as features
        # TODO Comodulogramm
        if do_comodulogram:
            print("Starting Comodulogram calculations")
            # calculating comodulogram of first and last window during experimental session
            comod = calculate_comodulogram(np.squeeze(window_data[0, 0, :]), sampling_frequency, do_plot=True, title="First Window")
            comod2 = calculate_comodulogram(np.squeeze(window_data[-1, 0, :]), sampling_frequency, do_plot=True, title="Last Window")

            n_lines = 3
            n_columns = 3
            fig, axs = plt.subplots(
                n_lines, n_columns, figsize=(4 * n_columns, 3 * n_lines))
            axs = axs.ravel()
            for ax_id in range(len(axs)):
                axs[ax_id].imshow(np.square(comod[ax_id] - comod2[ax_id]), origin="lower")

            plt.suptitle("R2 difference")

            plt.show()
            print("Skipping rest")

            # all_comods = calculate_all_comodulograms(window_data, sampling_frequency)
            continue

        # Step 8 : extract features from the data (Frequency transformation) + flattening data in some cases
        freq_windows = extract_frequencies(window_data, sampling_frequency)
        freq_components = np.reshape(freq_windows, (freq_windows.shape[0], -1))
        time_components = np.reshape(window_data, (window_data.shape[0], -1))

        freq_windows_norm = extract_frequencies(window_data, sampling_frequency, normalization=True, added_amp=False)
        freq_components_norm = np.reshape(freq_windows_norm, (freq_windows_norm.shape[0], -1))

        freq_windows_bins = extract_frequencies(window_data, sampling_frequency, freq_bins=freq_bins)
        freq_components_bins = np.reshape(freq_windows_bins, (freq_windows_bins.shape[0], -1))

        freq_windows_bins_norm = extract_frequencies(window_data, sampling_frequency, freq_bins=freq_bins, normalization=True, added_amp=False)
        freq_components_bins_norm = np.reshape(freq_windows_bins_norm, (freq_windows_bins_norm.shape[0], -1))

        complete_data = np.concatenate((complete_data, freq_components_norm), axis=0)
        complete_labels = np.concatenate((complete_labels, window_labels), axis=0)
        complete_run_id = np.concatenate((complete_run_id, path_id*np.ones((window_labels.size,))), axis=0)

    # end loop

    if show_graphs:
        plt.figure()
        plt.plot(complete_run_id)
        plt.show()

    from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
    from sklearn.svm import SVC
    from sklearn.model_selection import cross_val_score
    from sklearn.model_selection import RepeatedStratifiedKFold
    import pyriemann as pyr

    model1 = LinearDiscriminantAnalysis()
    model2 = SVC(kernel='rbf', C=1)
    model3 = SVC(kernel='linear')
    model4 = pyr.classification.MDM(metric=dict(mean='riemann', distance='riemann'))
    model5 = pyr.classification.TSclassifier(metric='riemann')

    model_schema = [model1, model2, model3]
    model_data = [complete_data, complete_data, complete_data]
    model_pca = [True, True, True]
    cv = RepeatedStratifiedKFold(n_splits=5, n_repeats=5, random_state=1)

    for x1 in range(len(model_schema)):
        model = model_schema[x1]
        data = model_data[x1]
        apply_pca = model_pca[x1]
        print(model)
        print(data.shape)
        if do_multi_class:
            threshold1 = np.percentile(complete_labels, [30])[0]
            threshold2 = np.percentile(complete_labels, [70])[0]

            if apply_pca:
                pipeline = sklearn.pipeline.make_pipeline(sklearn.decomposition.PCA(n_components=number_pca_components), model)
            else:
                pipeline = sklearn.pipeline.make_pipeline(model)

            final_label = (complete_labels > threshold1) * 1 + (complete_labels > threshold2) * 1
            scores = cross_val_score(pipeline, data, final_label, scoring='accuracy', cv=cv, n_jobs=-1)
            # summarize result
            print('Mean Accuracy: %.3f (%.3f)' % (np.mean(scores), np.std(scores)))
            #save_data_matrix[path_id, element_counter] = np.mean(scores)
            #element_counter += 1

        else:
            for perc in np.arange(10, 100, 20):
                threshold = np.percentile(complete_labels, [perc])[0]
                final_label = (complete_labels > threshold) * 1

                if apply_pca:
                    pipeline = sklearn.pipeline.make_pipeline(sklearn.decomposition.PCA(n_components=number_pca_components), model)
                else:
                    pipeline = sklearn.pipeline.make_pipeline(model)

                scores = cross_val_score(pipeline, data, final_label, scoring='balanced_accuracy', cv=cv, n_jobs=-1)
                # summarize result
                print('Mean Accuracy (%.3f): %.3f (%.3f)' % (perc, np.mean(scores), np.std(scores)))
                #save_data_matrix[path_id, element_counter] = np.mean(scores)
                #element_counter += 1


if __name__ == "__main__":
    process_pipeline_vigilance()
