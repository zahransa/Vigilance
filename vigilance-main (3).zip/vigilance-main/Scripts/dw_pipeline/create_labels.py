#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 21 2023

@author: dwobrock
"""

import numpy as np


def calculate_labels_from_file(path_to_file: str, sampling_rate: int, window_size: int, window_step: int,
                               method: str = 'bsi_adj', upper_rt_limit=2, ):
    """
    Function aimed at extracting the Balanced integrated score labels from the trigger file
    :param path_to_file: str, path to the csv file containing a column labeled "trigger" and one labeled "timestamp"
    :param sampling_rate: int, sampling rate of the other biosignal
    :param window_size: int, length of windows, in seconds, on which data will be gathered to calculate the BIS
    :param window_step: int, step size for the moving window, in seconds
    :param upper_rt_limit: int, maximal duration of inter stimulus interval or maximum time to give an input
    :param method: str, from ['bsi_adj','bsi','rt','pc','ies','rcs','lisas'], method to calculate the labels from
    :return: padded_bsi_scores: np.ndarray, array as long as the eeg recording with the BIS label at each moment in time
    :return: session_onset_time_ids: np.ndarray, array containing the location of the start and end of session blocks within the recording
    """

    # read file content
    import pandas as pd
    data_pandas_format = pd.read_csv(path_to_file)

    # conversion to obtain triggers and timestamps inside the dataframe
    work_data = data_pandas_format.copy()
    trigger_data = work_data.dropna(subset="trigger")
    trigger_timestamps = trigger_data.loc[:, "timestamp"].to_numpy()
    trigger_values = trigger_data.loc[:, "trigger"].to_numpy()

    # extract location of stimuli onsets and button presses
    stim_onset_ids = np.where((trigger_values == 40) | (trigger_values == 30) | (trigger_values == 50))[0]
    button_ids = np.where(trigger_values == 7)[0]

    # session start and end points
    session_onset_ids = np.where((trigger_values == 10) | (trigger_values == 11))[0]
    session_onset_time_ids = np.int_(np.round(trigger_timestamps[session_onset_ids] * sampling_rate))

    # transform into real time
    button_press_times = trigger_timestamps[button_ids] * sampling_rate
    stim_onset_times = trigger_timestamps[stim_onset_ids] * sampling_rate

    # selection is correct if, following the appearence or disappearence of a target stim, there is a button press
    # selection is correct if, following the appearence or disappearence of a non target stim, there is no button press
    previously_correct = 1 * (((trigger_values[stim_onset_ids] == 30) & (
                (trigger_values[stim_onset_ids + 1] == 7) | (trigger_values[stim_onset_ids + 2] == 7))) |
                              ((trigger_values[stim_onset_ids] == 50) & ((trigger_values[stim_onset_ids + 1] != 7) & (
                                          trigger_values[stim_onset_ids + 2] != 7))) |
                              ((trigger_values[stim_onset_ids] == 40) & ((trigger_values[stim_onset_ids + 1] != 7) & (
                                          trigger_values[stim_onset_ids + 2] != 7))))

    correct_hits = 1 * ((trigger_values[button_ids] == 7) & (
                (trigger_values[button_ids - 1] == 30) | (trigger_values[button_ids - 2] == 30)))

    # Calculate the response time to the closest previous stimulus
    response_time = -1 * np.ones((button_press_times.size,))
    import math
    for counter in range(response_time.size):
        time_differences = -1 * (stim_onset_times - button_press_times[counter])
        time_differences[time_differences < 0] = math.inf
        response_time[counter] = np.min(time_differences)

    # normalization of the response time to ensure it doesn't explode the potential labels
    response_time /= (upper_rt_limit * sampling_rate)

    # general values for scores
    general_pc = np.mean(previously_correct)
    general_rt = np.mean(response_time)
    # general_hits = np.mean(correct_hits)

    # calculate BIS scores
    window_size = window_size * sampling_rate
    window_step = window_step * sampling_rate

    starting_points = np.arange(0, data_pandas_format.shape[0] - window_size, window_step, dtype=int)
    ending_points = starting_points + window_size
    local_scores = np.zeros((starting_points.size,))

    for i in range(starting_points.size):
        start_point = starting_points[i]
        end_point = ending_points[i]

        locations_id_button = np.where((button_press_times < end_point) & (button_press_times >= start_point))[0]
        locations_id_stims = np.where((stim_onset_times < end_point) & (stim_onset_times >= start_point))[0]
        if (locations_id_button.size <= 1) | (locations_id_stims.size <= 1):
            continue
        local_prev_correct = previously_correct[locations_id_stims]
        local_resp_time = response_time[locations_id_button]
        local_hits = correct_hits[locations_id_button]
        match method:
            case "bis_adj":
                local_scores[i] = calculate_bsi_score(local_prev_correct, local_resp_time, general_pc, general_rt,
                                                      adapt=True)
            case "bis":
                local_scores[i] = calculate_bsi_score(local_prev_correct, local_resp_time, general_pc, general_rt,
                                                      adapt=False)
            case "ies":
                local_scores[i] = calculate_ies_score(local_hits, local_resp_time, adjust=False)
            case "ies_adj":
                local_scores[i] = calculate_ies_score(local_hits, local_resp_time, adjust=True)
            case "pc":
                local_scores[i] = calculate_pc_score(local_prev_correct)
            case "rt":
                local_scores[i] = calculate_rt_score(local_resp_time)
            case "rcs":
                local_scores[i] = calculate_rcs_score(local_prev_correct, local_resp_time)
            case "lisas":
                local_scores[i] = calculate_lisas_score(local_prev_correct, local_resp_time)
            case _:
                local_scores[i] = i
    # padding the data to the entirety of the recording
    tmp_mat = np.zeros((data_pandas_format.shape[0],))
    tmp_mat[np.int_(ending_points)] = 1
    idx = np.int_(tmp_mat.cumsum(-1) - 1)
    padded_scores = local_scores[idx]

    return padded_scores, session_onset_time_ids


def calculate_bsi_score(loc_prev_correc: np.ndarray, loc_resp_time: np.ndarray, gen_prev_correct, gen_resp_time,
                        adapt=True):
    """
    Calculate Balanced Integration score
    :param loc_prev_correc: ndarray, array of how many times the subject performed a correct input
    :param loc_resp_time: ndarray, array how long the person took to respond to stimuli during the interval
    :param gen_prev_correct: float, average ratio of correct responses across the observed data
    :param gen_resp_time: float, average response time to a stimulus across all of the data
    :param adapt: bool, flag if a corrected version of the bsi score should be used
    :return: bsi_score, float
    """
    if adapt:
        z_pc = (np.mean(loc_prev_correc) - gen_prev_correct) / (1 + np.std(loc_prev_correc))
        z_rt = (np.mean(loc_resp_time) - gen_resp_time) / (1 + np.std(loc_resp_time))
    else:
        z_pc = (np.mean(loc_prev_correc) - gen_prev_correct) / np.std(loc_prev_correc)
        z_rt = (np.mean(loc_resp_time) - gen_resp_time) / np.std(loc_resp_time)
    bsi_score = z_pc - z_rt
    return bsi_score


def calculate_ies_score(loc_hits: np.ndarray, loc_resp_time: np.ndarray, adjust=False):
    """
    Calculate the Inverse effective score
    :param loc_hits: ndarray, array of how many times the subject performed a correct input
    :param loc_resp_time: ndarray, array how long the person took to respond to stimuli during the interval
    :param adjust: bool, flag to adjust the inverse effective score, as to not give undefined numbers
    :return: ies_score, float
    """
    if adjust:
        ies_score = np.mean(loc_resp_time) / (1 + np.mean(loc_hits))
    else:
        ies_score = np.mean(loc_resp_time) / np.mean(loc_hits)
    return ies_score


def calculate_rt_score(loc_resp_time: np.ndarray):
    """
    Calculate the average response time
    :param loc_resp_time: ndarray, array how long the person took to respond to stimuli during the interval
    :return: rt_score, float
    """
    rt_score = np.mean(loc_resp_time)
    return rt_score


def calculate_pc_score(loc_prev_correc: np.ndarray):
    """
    Calculate the previous correct response ratio
    :param loc_prev_correc: ndarray, array of how many times the subject performed a correct input
    :return: pc_score, float
    """
    pc_score = np.mean(loc_prev_correc)
    return pc_score


def calculate_rcs_score(loc_prev_correc: np.ndarray, loc_resp_time: np.ndarray):
    """
    Calculate the Rate correct score
    :param loc_prev_correc: ndarray, array of how many times the subject performed a correct input
    :param loc_resp_time: ndarray, array how long the person took to respond to stimuli during the interval
    :return: rcs_score, float
    """
    rcs_score = np.sum(loc_prev_correc) / np.sum(loc_resp_time)
    return rcs_score


def calculate_lisas_score(loc_prev_correc: np.ndarray, loc_resp_time: np.ndarray):
    """
    Calculate the Linear Integrated Speed-accuracy score
    :param loc_prev_correc: ndarray, array of how many times the subject performed a correct input
    :param loc_resp_time: ndarray, array how long the person took to respond to stimuli during the interval
    :return: lisas_score, float
    """
    loc_p_error = np.abs(1 - loc_prev_correc)
    lisas_score = np.mean(loc_resp_time) + ((np.std(loc_resp_time) / np.std(loc_p_error)) * np.mean(loc_p_error))
    return lisas_score
