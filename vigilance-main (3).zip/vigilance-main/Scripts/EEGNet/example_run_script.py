# Description: Code to run EEGNet in within subbject design (with experiment tracking setup))
#-Author: Dmitrii Bryzgalov (dmitrii.bryzgalov@capgemini.com)

#%% imports
import os, sys
import numpy as np
from tensorflow.keras import backend as K
from tqdm import tqdm
from sklearn.model_selection import train_test_split, StratifiedKFold
# Get custom code
rootFolder = os.path.abspath(os.path.join(os.path.dirname(__file__), ''))
sys.path.insert(0, rootFolder)
sys.path.insert(1, os.path.expanduser('//'))
from eeg_data_management.lib import transform_data as data
from lib.models.simplestrnn import EEGNet
import lib.models.deep_utils as du
import lib.tracking.neptune_wrapper as nw
from lib.tracking.configuration import get_project_name, API

#%% directories
BASEDIR = os.path.expanduser('/vissat/') # Dima's path
DATADIR = os.path.expanduser('~/data/vissat/') # Dima's path
BASELOGS = os.path.join(BASEDIR, 'vissat_logs') # Dima's path
BASEMODELS = os.path.join(BASEDIR, 'vissat_models') # Dima's path
BASERESULTS = os.path.join(BASEDIR, 'vissat_results') # Dima's path
FINALFOLDER = 'test_eegnet_run_ws' # Final folder to save the results
PROJECT_TO_TRACK = 'cnns' # Project to track in neptune
# Define subjects (48 and 56 - starred)
SUBJECTS = [13, 14, 15, 16, 18, 21, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 52, 54, 56, 60, 62, 64]

#%% General Parameters
SAMPLING_RATE = 250
LOWF = 5 # Low bound for filtering data
HIGHF = 40 # High bound for filtering data
TMIN = 0 # At which time point from trigger to start epoch
TMAX = 3 # At which time point from trigger to stop epoch
triggers = {'7.5Hz': 1075, '10Hz': 1010, '12Hz': 1012} # Set of events to retrieve from datasets
# number of keys in triggers will be used as a number of classes to classify
WDUR = 1 # Durations of time window to classify
TDELTA = 0.05 # Sliding window step for data augmentation
RSEED = 33 # random seed for shuffling the data
TEST_SPLIT = 0.2 # test split = testsplit
VAL_SPLIT = 0.15 # validation split = (1 - testsplit)*testsplit
# EEGNet parameters
N_EPOCHS = 200 # Number of epochs to train
BATCH_SIZE = 30 # Number of batches to split the training data into
OPTIMIZER = 'nadam'
DROPOUT_RATE = 0.5
F1 = 12 # Frequency filter
D = 8 # Default spatial filter - is changed to nchannels*1.5 when calling EEGNet
NORM_RATE = 0.25 # Extent to which one wants to contran kernels in last dense layer
isPreservedOrder = True # Whether to preserve the order of the data
EARLY_STOPPING = True # Number of epochs to wait before early stopping
FOLDER_CODE = os.path.expanduser('/deep_eeg')
SOURCE_FILES = [os.path.join(FOLDER_CODE, 'lib', 'models', 'eegnet.py'),
                os.path.join(FOLDER_CODE, 'lib', 'models', 'deep_utils.py'),
                os.path.join(FOLDER_CODE, 'lib', 'models', 'neptune_wrapper.py'),
                os.path.join(FOLDER_CODE, 'config', 'requirements.txt'),
                os.path.join(FOLDER_CODE, 'config', 'environment.yml'),
                os.path.basename(__file__)]

def main():
    #%% Load data, filter them and epoch them
    dataEpoched = []
    idTrigger = []
    print('Loading data...')
    for isubject, subject in enumerate(tqdm(SUBJECTS)):
        mneDataFSub = data.load_data(DATADIR, 'vissat', subject)
        dataEpochedSub, idTriggerSub = data.extract_epochs(mneDataFSub, triggers)
        dataEpoched.append(dataEpochedSub)
        idTrigger.append(idTriggerSub)

    #%% Initialize parameters
    samples = int(WDUR*SAMPLING_RATE)
    kernLength = int(samples/2)
    nchannels = dataEpoched[0].shape[1]
    parameters = du.Params(Chans=nchannels, wdur=WDUR, samplingRate=SAMPLING_RATE,
                           dropoutRate=DROPOUT_RATE, kernLength=kernLength, F1=F1,
                           D=int(nchannels*1.5), F2=F1*int(nchannels*1.5),
                           norm_rate=NORM_RATE, dropoutType='Dropout')
    parameters.add_parameters(isAugment=True, isSaccade=False, lowFilter=LOWF,
                              highFilter=HIGHF, wdur=WDUR, tdelta=TDELTA,
                              randomSeed=RSEED, triggers=triggers, tmin=TMIN,
                              tmax=TMAX, testSplit=TEST_SPLIT, valSplit=VAL_SPLIT,
                              isPreservedOrder=isPreservedOrder,
                              earlyStopping=EARLY_STOPPING, subjects=SUBJECTS,
                              kfolds=5)

    #%% Augment the data, create labels, scale
    augmented = data.transform_data(dataEpoched, WDUR, TDELTA, idTrigger, isPooled=False,
                                    isSaccade=False)
    (nndata, maskSub, classN) = augmented
    labels = []
    for isubject in range(len(SUBJECTS)):
        labels.append(data.create_labels(triggers, maskSub[isubject], classN[isubject]))
        labels[isubject] = labels[isubject][:, :len(triggers.keys())]
        nndata[isubject] = data.ensure_nonzero_signals(nndata[isubject])
        nndata[isubject] = data.scale_data(nndata[isubject])

    #%% Set-up the tracking
    projectName = get_project_name(PROJECT_TO_TRACK)
    neptuneTracker = nw.NeptuneWrapper(projectName=projectName, api=API,
                                       dataDir=DATADIR, params=parameters,
                                       sourceFiles=SOURCE_FILES)
    neptuneTracker.create_run()

    #%% Run the model
    results = []
    k_fold = StratifiedKFold(n_splits=int(1 / TEST_SPLIT), shuffle=False)
    # Train networks
    for isubject, subject in enumerate(SUBJECTS):
        results.append([])
        labelsForFold = np.argmax(labels[isubject][:, :len(triggers.keys())], axis=1)

        for ifold, (train, test) in enumerate( k_fold.split(nndata[isubject], labelsForFold)):
            # Get data
            xtrain, xval, ytrain, yval = train_test_split(nndata[isubject][train],
                                                          labels[isubject][train],
                                                          test_size=VAL_SPLIT,
                                                          random_state=RSEED,
                                                          shuffle=True)
            # Set up path
            mPathSave = os.path.join(BASEMODELS, FINALFOLDER, ('subj' + str(subject)),
                                     f'fold{ifold + 1}')  # model
            rPathSave = os.path.join(BASERESULTS, FINALFOLDER, ('subj' + str(subject)),
                                     f'fold{ifold + 1}')  # results
            lPathSave = os.path.join(BASELOGS, FINALFOLDER, ('subj' + str(subject)),
                                     f'fold{ifold + 1}')  # logs
            if not os.path.isdir(mPathSave):
                os.makedirs(mPathSave)
            if not os.path.isdir(rPathSave):
                os.makedirs(rPathSave)
            if not os.path.isdir(lPathSave):
                os.makedirs(lPathSave)
            K.clear_session() # Clear the session to avoid memory leaks
            print(f'Training network for subject {subject}, fold{ifold + 1}')
            # Train/test
            neptuneCallback = neptuneTracker.get_tensorflow_keras_callback(level=f'subj{subject}/fold{ifold+1}')
            model = EEGNet(len(triggers.keys()), parameters, design='within',
                           dirModel=mPathSave, dirLog=lPathSave,
                           dirResult=rPathSave)
            model.compile(optimizer=OPTIMIZER)
            history = model.train(xtrain, ytrain, N_EPOCHS, batchSize=BATCH_SIZE,
                                  valData=(xval, yval), earlyStopping=EARLY_STOPPING,
                                  callbacksToAdd=neptuneCallback)

            predicted = model.test(nndata[isubject][test], batchSize=BATCH_SIZE)
            acc_temp, _ = model.evaluate(predicted, labels[isubject][test],
                                         isSave=False)
            print(f'Accuracy of model for subject#{subject} is {acc_temp:.02%}')
            results[isubject].append(
                model.evaluate_fully(predicted, labels[isubject][test], isSave=False))
            _, cmName = du.plot_confusion_matrix(results[isubject][ifold]['confusionMatrix'],
                                                    list(triggers.keys()),
                                                    saveDir=rPathSave)
            _, cmNameNorm = du.plot_confusion_matrix(results[isubject][ifold]['confusionMatrix'],
                                                            list(triggers.keys()),
                                                            normalize=True,
                                                            saveDir=rPathSave)
            model.save_parameters()

            # Log the results to Neptune
            metricsToTrack = ['loss', 'accuracy', 'val_loss', 'val_accuracy']
            for metricName in metricsToTrack:
                firstLevel = f'subj{subject}/fold{ifold+1}/train'
                neptuneTracker.log_parameters(metricName, history.history[metricName],
                                              firstLevel=firstLevel)
            for resultName in results[isubject][ifold].keys():
                firstLevel = f'subj{subject}/fold{ifold+1}/test'
                neptuneTracker.log_parameters(resultName, results[isubject][ifold][resultName],
                                              firstLevel=firstLevel)
            neptuneTracker.log_artifact(f'confusionMatrix_subj{subject}_fold{ifold+1}',
                                        os.path.join(rPathSave, cmName))
            neptuneTracker.log_artifact(f'confusionMatrixNorm_subj{subject}_fold{ifold+1}',
                                        os.path.join(rPathSave, cmNameNorm))

    neptuneTracker.stop_run()


if __name__ == '__main__':
    main()