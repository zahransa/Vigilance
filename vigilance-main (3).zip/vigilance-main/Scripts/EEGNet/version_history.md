# Modifications through the versions

### Version 1.0.2
1 march 2023
* Refactored package structure (config file moved to `config/`, `lib/networks/` renamed into `lib/models/`) 
* Added example script that uses the Neptune tracking
* `Params` class in `deep_utils` is stripped of EEGNet specific parameters
* `ANN.train()` now records all the metrics after training
* SimplestRNN made compatible with the version 1
* In `NeptuneWrapper` class, made possible to add levels to keras callback 

### Version 1.0.1
28 february 2023
* Refactored package structure
* Added possibility for experiment tracking with Neptune.AI
* Added possibility to add more callbacks to defaultnet.train()
* Added a function to plot confusion matrix in deep_utils

### Version 1.0.0
21 february 2023
* Major refactoring of the code: defaultnet becomes template for all other networks
* Major refactoring of the code: each architecture is now a separate class
* Major refactoring of the code: deep_utils is now a separate module
* Code is covered by tests
* importData is refactored and moved to its own repository

--------------------------------------------------------------------------------

### Version 0.3.7
xx october 2022
* Added possibiility to filter out high-amplitude artifacts at epochs stage

### Version 0.3.6
03 october 2022
* Updated for python 3.10
* Added more evaluation metrics
* Removed redundant isPreservedOrder parameter from transform_data
* Minor bug fixes

### Version 0.3.5
29 august 2022
* Improved nan-robustness of decide_class

### Version 0.3.4
22 august 2022
* Added possibility to conserve epoch order when extracting epochs from dataset
* Minor bug fixes

### Version 0.3.3
17 august 2022
* Corrected bug in EEGNet initialization
* Speeded up augmentation considerably and reworked workflow of transform_data

### Version 0.3.2
03 august 2022
* Added no-dataset loading option to transform_data
* Minor code improvements

### Version 0.3.1
24 june 2022
* Renamed augment_data function
* Minor bug fixes

### Version 0.3
31 may 2022
* Added EEGOnline class which performs sliding window classification in online circumstances

### Version 0.2.3
25 may 2022
* Added a feature to save parameters for the concrete instance of EEGNet
* Minor bug fixes

### Version 0.2.2
17-18 may 2022
* Added possibility to give validation dataset to eegnet.train()
* Added flexibility of selecting channels from the datasets while still keeping loading of all channels default
* (!) Corrected a large bug in create_labels with pooled design

### Version 0.2.1
12 may 2022
* Generalized the data import codes to be able to load files from different datasets
* Minor changes in docstrings and example_notebook

### Version 0.2
09 may 2022
* In datasets.tranform_data_vissat <augment_data> and <create_labels> are changed for easier use in cross- and within-subject paradigms
* Minor docstrings changes

### Version 0.1
03 may 2022
* EEGNet rewritten as class, comments are added
* Example is changed accordingly
* Big mistake in fbCCA algo corrected, and minor adjustments made
* Noted that in fbCCA, when taking the decision, the correlation coefficients are not squared as in the paper
* Added possibility to get 1D labels in tranform_data_vissat module








































