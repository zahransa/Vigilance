# Description: Code to prepare Vigilance data for classification with EEGNet
#-Author: Nicolai Wolpert (nicolai.wolpert@capgemini.com)

#%% imports
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import mne
from tensorflow.keras import backend as K
from tqdm import tqdm
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import StratifiedKFold

from lib.models.eegnet import EEGNet
import lib.models.deep_utils as du
import lib.tracking.neptune_wrapper as nw
from lib.tracking.configuration import get_project_name, API

#%% directories
BASEDIR ='C:/Users/nwolpert/Documents/Mind&Act/Vigilance/'

PROJECT_TO_TRACK = 'Stress' # Project to track in neptune
# Specify subjects for the different tasks with clean EEG & behavior
tasks_subjects = {'atc': ['01', '03', '04', '05', '08', '15', '21', '23', '24'],
                  'line_task_sim': ['02', '03', '04', '18', '25'],
                  'line_task_succ': ['02', '04', '05', '07'],
                  'oddball': ['04', '07']}
FINALFOLDER = BASEDIR + 'Data_work/eegnet/' # Final folder to save the results
FOLDER_CODE = os.path.join(os.path.dirname(os.getcwd()), 'Pipeline_DeepClassifiers_Vigilance')

#%% Data Parameters
DATASET = 'Vigilance'
CHANNEL_NAMES = ['Pz', 'O1', 'O2', 'Fz', 'F3', 'F4', 'Fp1', 'Fp2']
SAMPLING_RATE = 250
LOWF = 1 # Low bound for filtering data
HIGHF = 40 # High bound for filtering data
# Epoch duration in seconds
EPOCH_DURATION = 5
EPOCH_DURATION_SAMPLES = SAMPLING_RATE * EPOCH_DURATION
# Define the periods for the classes = data from the first vs. last <PERIODS_CLASSES> minutes
PERIODS_CLASSES = 10
cleanHighAmpArtifacts = False
TRIGGERS_CODES = {
    'TRIGGER_START_EXPERIMENT': 1,
    'TRIGGER_END_EXPERIMENT': 2,
    'TRIGGER_START_BLOCK': 10,
    'TRIGGER_END_BLOCK': 11,
    'TRIGGER_START_TRIAL': 20,
    'TRIGGER_END_TRIAL': 21,
    'TRIGGER_BUTTON_PRESS': 7
}

#%% Deep Learning parameters
LEARNING_RATE = 0.01
RSEED = 33 # random seed for shuffling the data
TEST_SPLIT = 0.2 # test split = testsplit
VAL_SPLIT = 0.15 # validation split = (1 - testsplit)*testsplit
N_EPOCHS = 400#200 # Number of epochs to train
BATCH_SIZE = 30 # Number of batches to split the training data into
OPTIMIZER = 'nadam'
DROPOUT_RATE = 0.5
F1 = 12 # Frequency filter
D = 8 # Default spatial filter - is changed to nchannels*1.5 when calling EEGNet
NORM_RATE = 0.25 # Extent to which one wants to contran kernels in last dense layer
isPreservedOrder = True # Whether to preserve the order of the data
EARLY_STOPPING = False # Number of epochs to wait before early stopping
SOURCE_FILES = [os.path.join(FOLDER_CODE, 'lib', 'models', 'eegnet.py'),
                os.path.join(FOLDER_CODE, 'lib', 'models', 'deep_utils.py'),
                os.path.join(FOLDER_CODE, 'lib', 'tracking', 'neptune_wrapper.py'),
                os.path.join(FOLDER_CODE, 'config', 'requirements.txt'),
                os.path.join(FOLDER_CODE, 'config', 'environment.yml'),
                os.path.basename(__file__)]

def load_data(data_csv, samplingRate=SAMPLING_RATE, channelsToGet='EEG', isFilt=True, notchFilt=True, lowf=1, highf=40,
              verbose=False):
    """ Load concatenated data from established Mind&Act datasets
    This function looks for the binary file with the name defined by the type of
    the dataset (<dataName>) and loads them

    Inputs:

      data_csv        : DataFrame
      subjectId       : str, subject number to load
      samplingRate    : int, sampling frequency
      channelsToGet   : str or list, optional. channels to load from the dataset
                        <dataName>. If 'all', it will load all existing
                        channels. If 'EEG', it will load all EEG channels. One can also
                        pass a list with real names of electrodes (beware,
                        case-sensitive; example: ['O1', 'Fp1']), a list with
                        regions (example: ['occipital', 'frontal']), or a
                        combination of both (example: ['O1', 'parietal']).
                        Default='all'
      typeFile        : str, optional. For dataset where there are calibration
                        and test files, you need to specify which ones you want
                        to load. Default=[]
      isFilt          : bool, optional. Whether to filter the data or not
                        (default - True)
      lowf            : float, optional. If isFilt=True, lower limit for
                        band-pass filter (default - 5)
      highf           : float, optional. If isFilt=True, higher limit for
                        band-pass filter (default - 40)
      verbose         : bool, optional. Delegates whether the function should be
                        verbose. (Default - False)

    Outputs:

      loadedData      : obj, MNE object of continous data
    """

    # Load .csv
    if verbose:
        print(f'Loading data')
    data_csv['trigger'] = data_csv['trigger'].fillna(0)
    data_csv.set_index('timestamp', inplace=True)

    all_ch_names = list(data_csv.columns)
    if channelsToGet=='EEG':
        chNames = [ch for ch in all_ch_names if ch !='ECG']
        chTypes = ['eeg'] * (len(chNames)-1) + ['stim']
        if 'ECG' in list(data_csv.columns):
            data_csv.drop(['ECG'], axis=1, inplace=True)

    ### Create MNE raw data object
    # Information about dataset
    info = mne.create_info(chNames, samplingRate, chTypes)
    # Create the dataset
    mneData = mne.io.RawArray(data_csv.values.T, info)

    if notchFilt:
        if verbose:
            print('Notch-filtering power line noise')
        mneData = mneData.notch_filter(freqs=[50, 100], filter_length='auto', method='fir', notch_widths=None,
                             trans_bandwidth=1.0, n_jobs=1, iir_params=None, mt_bandwidth=None, p_value=0.05,
                             phase='zero', fir_window='hamming', fir_design='firwin', pad='reflect_limited',
                             verbose=None)
    if isFilt:
        if verbose:
            print(f'Filtering data between {lowf} and {highf} Hz')
        mneData = mneData.filter(lowf, highf, fir_design='firwin', verbose=verbose)

    return mneData

def extract_epochs(task, subject, EPOCH_DURATION, cleanHighAmpArtifacts=True):
    """ Extract epochs from the MNE objects that were loaded by <load_data> or
    <load_new_file>

    This function looks for triggers with codes defined in the dict <triggers>
    and returns a numpy array with epochs as well as alist of length equal to
    the number of classes, within each of which there is a numpy array of indices
    of epochs that belong to this class

    Inputs:
      task:             str, task
      subject:          str, subject ID
      EPOCH_DURATION:   float. End of epoch relative to the trigger, in sec.
      cleanHighAmpArtifacts : bool, optional. Whether to clean high amplitude
                                artifacts or not (Default - False)

    Outputs:

      dataEpoched     : np.array, with extracted epochs of shape (epochs, channels, time)
      idTrigger       : list, with indices of epochs that belong to each class
    """

    # Amplitude artifacts parameters
    HIGH_AMP_CRITERION = 500  # 0.5 mV
    FLAT_CHANNEL_CRITERION = 1  # 1 µV
    if cleanHighAmpArtifacts:
        reject_criteria = dict(eeg=HIGH_AMP_CRITERION)
        flat_criteria = dict(eeg=FLAT_CHANNEL_CRITERION)
    else:
        reject_criteria = {}
        flat_criteria = {}

    data_csv = pd.read_csv(BASEDIR + f'Data_raw/{task}/EEG/{subject}/vigilance_{task}_EEG_{subject}.csv')
    # Extract data from the experimental block only (corresponds to last block triggers)
    # Oddball task has one training and four experimental blocks
    if task == 'oddball':
        ind_start_exp = list(data_csv.loc[data_csv.trigger==TRIGGERS_CODES["TRIGGER_START_BLOCK"]].index)[1]
        ind_end_exp = list(data_csv.loc[data_csv.trigger==TRIGGERS_CODES["TRIGGER_END_BLOCK"]].index)[-1]
    else:
        ind_start_exp = list(data_csv.loc[data_csv.trigger==TRIGGERS_CODES["TRIGGER_START_BLOCK"]].index)[-1]
        ind_end_exp = list(data_csv.loc[data_csv.trigger==TRIGGERS_CODES["TRIGGER_END_BLOCK"]].index)[-1]

    data_csv = data_csv.loc[ind_start_exp:ind_end_exp].reset_index(drop=True)
    # Set all triggers to zero, they are not used here. New custom triggers will be inserted that mark the start of
    # each epoch.
    data_csv['trigger'] = 0

    # Extract data from the beginning vs. end = first vs. last <PERIODS_CLASSES> minutes
    data_beginning = data_csv.loc[data_csv['timestamp']<=(data_csv['timestamp'][0] + PERIODS_CLASSES*60)]
    data_beginning.reset_index(inplace=True, drop=True)
    data_end = data_csv.loc[data_csv['timestamp']>=(data_csv['timestamp'].iloc[-1] - PERIODS_CLASSES*60)]
    data_end.reset_index(inplace=True, drop=True)

    ### Extract epochs from the beginning = "high vigilance"
    nsamples_beginning = data_beginning.shape[0]

    # Create a custom 'events' list of samples of interest that will be used to epoch the data.
    idx_start_epoch = 0
    events = []
    epochs_start_end = []       # just created to keep track of for potential debugging
    iepoch=0
    while (idx_start_epoch + EPOCH_DURATION_SAMPLES) <= nsamples_beginning:
        idx_end_epoch = idx_start_epoch + EPOCH_DURATION_SAMPLES

        if len(events) == 0:
            events = np.array([idx_start_epoch, 0, 1])
            epochs_start_end = np.array([idx_start_epoch, idx_end_epoch])
        else:
            events = np.vstack((events, np.array([idx_start_epoch, 0, 1])))
            epochs_start_end = np.vstack((epochs_start_end, np.array([idx_start_epoch, idx_end_epoch])))
        # Insert trigger that marks that this is the beginning of an epoch
        data_beginning.loc[idx_start_epoch, 'trigger'] = 1

        iepoch += 1
        idx_start_epoch = idx_end_epoch + 1

    # Transform csv data to MNE object
    mneData_beginning = load_data(data_beginning)

    # Epoch to selected starts of epochs
    dataEpoched_high_vigilance = mne.Epochs(mneData_beginning, events, event_id={'TRIGGER_START_EPOCH' : 1}, tmin=0,
                                            tmax=EPOCH_DURATION-(1/SAMPLING_RATE), baseline=None, preload=True, verbose=False,
                                            on_missing='warn', reject=reject_criteria, flat=flat_criteria)
    dataEpoched_high_vigilance = dataEpoched_high_vigilance.pick_types(eeg=True)

    ### Report artifacts
    percDropped = dataEpoched_high_vigilance.drop_log_stats()
    if percDropped > 0:
        # Report here percentage of epochs dropped for each class
        print(f'Warning: Overall {percDropped:.2f}% epochs were dropped for high vigilance class '
              f'due to artifacts')
    else:
        print('All epochs clean for high vigilance class')

    ### Extract epochs from the end = "low vigilance"

    nsamples_end = data_end.shape[0]

    # Create a custom 'events' list of samples of interest that will be used to epoch the data.
    idx_start_epoch = 0
    events = []
    epochs_start_end = []       # just created to keep track of for potential debugging
    iepoch=0
    while (idx_start_epoch + EPOCH_DURATION_SAMPLES) <= nsamples_end:
        idx_end_epoch = idx_start_epoch + EPOCH_DURATION_SAMPLES

        if len(events) == 0:
            events = np.array([idx_start_epoch, 0, 1])
            epochs_start_end = np.array([idx_start_epoch, idx_end_epoch])
        else:
            events = np.vstack((events, np.array([idx_start_epoch, 0, 1])))
            epochs_start_end = np.vstack((epochs_start_end, np.array([idx_start_epoch, idx_end_epoch])))
        # Insert trigger that marks that this is the beginning of an epoch
        data_end.loc[idx_start_epoch, 'trigger'] = 1

        iepoch += 1
        idx_start_epoch = idx_end_epoch + 1

    # Transform csv data to MNE object
    mneData_end = load_data(data_end)

    # Epoch to selected starts of epochs
    dataEpoched_low_vigilance = mne.Epochs(mneData_end, events, event_id={'TRIGGER_START_EPOCH' : 1}, tmin=0,
                                            tmax=EPOCH_DURATION-(1/SAMPLING_RATE), baseline=None, preload=True, verbose=False,
                                            on_missing='warn', reject=reject_criteria, flat=flat_criteria)
    dataEpoched_low_vigilance = dataEpoched_low_vigilance.pick_types(eeg=True)

    ### Report artifacts
    percDropped = dataEpoched_low_vigilance.drop_log_stats()
    if percDropped > 0:
        # Report here percentage of epochs dropped for each class
        print(f'Warning: Overall {percDropped:.2f}% epochs were dropped for low vigilance class '
              f'due to artifacts')
    else:
        print('All epochs clean for low vigilance class')

    '''
    # Optional: Show signals
    fig, axs = plt.subplots(int(np.ceil(len(CHANNEL_NAMES) / 2)), 2, figsize=(10, 5), sharex=True)
    axs = axs.flatten()
    for ichan, channel in enumerate(CHANNEL_NAMES):
        axs[ichan].plot(mneData._data[ichan])
        axs[ichan].set_title(task + ', subject' + subject + ', ' + channel, fontsize=15)
    plt.tight_layout()
    plt.show()
    '''

    return dataEpoched_high_vigilance, dataEpoched_low_vigilance

def ensure_nonzero_signals(nndata):
    """ Replaces all-zero windows with the signal from neigboring channels

    WARNING: Not implemented replacement further than 1 row

    Inputs:

      nndata          : nparray, windows with brain signals of shape
                        (windows, channels, time)

    Outputs:

      nndata          : nparray, windows with brain signals of shape
                        (windows, channels, time)
    """

    for iw in range(nndata.shape[0]):
        for ielec in range(nndata.shape[1]):
            if len(np.where(nndata[iw, ielec, :] == 0)[0]) == nndata.shape[2]:
                if ielec == 0:
                    nndata[iw, ielec, :] = nndata[iw, ielec + 1, :]
                elif ielec == nndata.shape[1] - 1:
                    nndata[iw, ielec, :] = nndata[iw, ielec - 1, :]
                else:
                    nndata[iw, ielec, :] = nndata[iw, ielec + 1, :]

    return nndata


def scale_data(nndata, typeS='minOneToOne', verbose=True):
    """ Scale each time window independently of others using MinMax scaling

    Inputs:

      nndata          : nparray, windows with brain signals of shape
                        (windows, channels, time)
      typeS           : str, optional. If 'minOneToOne' it scales a window from
                        -1 to 1; of 'zeroToOne' it scales a window from 0 to 1
                        (Default - 'minOneToOne')
      verbose         : bool, optional. Delegates whether the function should be
                        verbose. (Default - False)

    Outputs:

      nndata          : nparray, windows with brain signals of shape
                        (windows, channels, time)
    """

    if typeS == 'minOneToOne':
        if verbose:
            print(f'Scaling each epoch between -1 and 1')
    elif typeS == 'zeroToOne':
        if verbose:
            print(f'Scaling each epoch between 0 and 1')
    else:
        raise ValueError('typeS is either "minOneToOne" or "zeroToOne"')

    for iw in tqdm(range(nndata.shape[0]), disable=not verbose):
        for ielec in range(nndata.shape[1]):
            toscale = nndata[iw, ielec, :]
            if typeS == 'minOneToOne':
                nndata[iw, ielec, :] = 2 * ((toscale - np.min(toscale)) /
                                            (np.max(toscale) - np.min(
                                                toscale))) - 1
            elif typeS == 'zeroToOne':
                nndata[iw, ielec, :] = (toscale - np.min(toscale)) / (
                        np.max(toscale)
                        - np.min(toscale))

    return nndata

def transform_data(tasks_subjects, EPOCH_DURATION, cleanHighAmpArtifacts):

    #%% Load data, filter them and epoch them
    dataEpoched = []
    # note indeces of epochs for each condition
    idTrigger_per_conditon = {'beginning': [], 'end': []}
    nepochs = 0
    # keep track of subject and condition
    epoch_info = pd.DataFrame(columns=['task_subject', 'condition'])
    print('Loading data...')
    for task in tasks_subjects.keys():
        for subject in tasks_subjects[task]:
            dataEpoched_high_vigilance, dataEpoched_low_vigilance = extract_epochs(task, subject, EPOCH_DURATION,
                                                                                   cleanHighAmpArtifacts)
            dataEpoched.append(dataEpoched_high_vigilance)
            dataEpoched.append(dataEpoched_low_vigilance)

            # note subject and block correspondence for each epoch
            for iepoch in range(len(dataEpoched_high_vigilance)):
                epoch_info = epoch_info.append(pd.DataFrame({'task_subject': [task + '_' + subject], 'condition': ['high']}),
                                               ignore_index=True)
            for iepoch in range(len(dataEpoched_low_vigilance)):
                epoch_info = epoch_info.append(pd.DataFrame({'task_subject': [task + '_' + subject], 'condition': ['low']}),
                                               ignore_index=True)

            nepochs = nepochs + len(dataEpoched_high_vigilance) + len(dataEpoched_low_vigilance)

    ### Append all epochs
    for iepoch in range(len(dataEpoched)):
        if iepoch==0:
            allData = dataEpoched[iepoch].get_data()
        else:
            allData = np.concatenate([allData, dataEpoched[iepoch].get_data()], 0)
    allData = ensure_nonzero_signals(allData)
    allData = scale_data(allData)
    
    allLabels = list(epoch_info['condition'])
    allLabels = np.array([1 if l == 'high' else 2 for l in allLabels])
    allLabels = np.expand_dims(allLabels, axis=1)
    enc = OneHotEncoder()
    enc.fit(allLabels)
    allLabels = enc.transform(allLabels).toarray().astype('float32')

    return allData, allLabels, epoch_info


def main():

    # %% Load data, filter them and epoch them
    allData, allLabels, epoch_info = transform_data(tasks_subjects, EPOCH_DURATION, cleanHighAmpArtifacts)

    # %% Initialize parameters
    samples = int(EPOCH_DURATION * SAMPLING_RATE)
    kernLength = int(samples / 2)
    nchannels = allData.shape[1]
    parameters = du.Params(dataset=DATASET, Chans=nchannels, wdur=EPOCH_DURATION, samplingRate=SAMPLING_RATE,
                           dropoutRate=DROPOUT_RATE, kernLength=kernLength, F1=F1,
                           D=int(nchannels * 1.5), F2=F1 * int(nchannels * 1.5),
                           norm_rate=NORM_RATE, dropoutType='Dropout')
    parameters.add_parameters(learning_rate=LEARNING_RATE, isSaccade=False, lowFilter=LOWF,
                              highFilter=HIGHF, wdur=EPOCH_DURATION, randomSeed=RSEED,
                              triggers={'TRIGGER_START_EPOCH' : 1}, tmin=0, tmax=EPOCH_DURATION,
                              cleanHighAmpArtifacts=cleanHighAmpArtifacts,
                              testSplit=TEST_SPLIT, valSplit=VAL_SPLIT,
                              isPreservedOrder=isPreservedOrder,
                              earlyStopping=EARLY_STOPPING, tasks_subjects=tasks_subjects,
                              kfolds=int(1 / TEST_SPLIT))

    # %% Set-up the tracking
    projectName = get_project_name(PROJECT_TO_TRACK)
    neptuneTracker = nw.NeptuneWrapper(projectName=projectName, api=API,
                                       # Nicolai removed dataDir=DATADIR since not working
                                       params=parameters,
                                       sourceFiles=SOURCE_FILES)
    neptuneTracker.create_run()

    ### Train/test split
    # Stratify subject and target label (condition)

    results = []
    k_fold = StratifiedKFold(n_splits=int(1 / TEST_SPLIT), shuffle=True, random_state=RSEED)
    for ifold, (train_val_index, test_index) in enumerate(k_fold.split(epoch_info, epoch_info.task_subject, epoch_info.condition)):
        print(ifold)

        # Split into train and validation stratifying for subject and label again
        val_index = list(epoch_info.loc[train_val_index].groupby(["task_subject", "condition"], group_keys=False). \
                         apply(lambda x: x.sample(frac=VAL_SPLIT)).index)
        train_index = list(set(train_val_index) - set(val_index))

        '''
        from collections import Counter
        epoch_info.loc[train_index, 'subject'].value_counts()
        epoch_info.loc[val_index, 'subject'].value_counts()
        epoch_info.loc[test_index, 'subject'].value_counts()

        epoch_info.loc[train_index, 'condition'].value_counts()
        epoch_info.loc[val_index, 'condition'].value_counts()
        epoch_info.loc[test_index, 'condition'].value_counts()
        '''

        xtrain = allData[train_index]
        xval = allData[val_index]
        ytrain = allLabels[train_index]
        yval = allLabels[val_index]

        # Set up path
        mPathSave = os.path.join(FINALFOLDER, f'fold{ifold + 1}')  # model
        rPathSave = os.path.join(FINALFOLDER, f'fold{ifold + 1}')  # results
        lPathSave = os.path.join(FINALFOLDER, f'fold{ifold + 1}')  # logs
        if not os.path.isdir(mPathSave):
            os.makedirs(mPathSave)
        if not os.path.isdir(rPathSave):
            os.makedirs(rPathSave)
        if not os.path.isdir(lPathSave):
            os.makedirs(lPathSave)
        K.clear_session()  # Clear the session to avoid memory leaks
        print(f'Training network for fold{ifold + 1}')

        # Train/test
        neptuneCallback = neptuneTracker.get_tensorflow_keras_callback(level=f'fold{ifold + 1}')
        model = EEGNet(2, parameters, design='cross',  # corrected 27.03.: '2' instead of 'len(triggers.keys())'
                       dirModel=mPathSave, dirLog=lPathSave,
                       dirResult=rPathSave)
        model.compile(learning_rate=LEARNING_RATE, optimizer=OPTIMIZER)
        ### Added Nicolai - now with learning rate schedule
        model.fix_learning_rate_schedule(lrSchedulerClass=du.LRSchedulerExpDecay,
                                           initLR=0.1, startDecay=5, decayRate=-0.03)
        history = model.train(xtrain, ytrain, N_EPOCHS, batchSize=BATCH_SIZE,
                              valData=(xval, yval), earlyStopping=EARLY_STOPPING,
                              callbacksToAdd=neptuneCallback)

        predicted = model.test(allData[test_index], batchSize=BATCH_SIZE)
        # acc_temp, _ = model.evaluate(predicted, allLabels[test_index], isSave=False)
        acc_temp = model.evaluate(predicted, allLabels[test_index], isSave=False)  # Nicolai removed accuraciesSub
        print(f'Accuracy of model is {acc_temp:.02%}')
        results.append(model.evaluate_fully(predicted, allLabels[test_index], isSave=False))
        _, cmName = du.plot_confusion_matrix(results[ifold]['confusionMatrix'],
                                             ['high', 'low'],
                                             saveDir=rPathSave)
        _, cmNameNorm = du.plot_confusion_matrix(results[ifold]['confusionMatrix'],
                                                 ['high', 'low'],
                                                 normalize=True,
                                                 saveDir=rPathSave)
        model.save_parameters()

        # Log the results to Neptune
        metricsToTrack = ['loss', 'accuracy', 'val_loss', 'val_accuracy']
        for metricName in metricsToTrack:
            firstLevel = f'fold{ifold + 1}/train'
            neptuneTracker.log_parameters(metricName, history.history[metricName], firstLevel=firstLevel)
        for resultName in results[ifold].keys():
            firstLevel = f'fold{ifold + 1}/test'
            neptuneTracker.log_parameters(resultName, results[ifold][resultName], firstLevel=firstLevel)
        neptuneTracker.log_artifact(f'confusionMatrix_fold{ifold + 1}',
                                    os.path.join(rPathSave, cmName))
        neptuneTracker.log_artifact(f'confusionMatrixNorm_fold{ifold + 1}',
                                    os.path.join(rPathSave, cmNameNorm))

    neptuneTracker.stop_run()


if __name__ == '__main__':
    main()
