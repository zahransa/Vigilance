# Mind & Act Deep Learning Tools for SSVEP-BCI v1.0

This repository is created to facilitate classification of SSVEP at several Mind & Act sub-projects, for example:

* [VISSAT](https://gitlab.oneforge.altran-onesoftware.fr/france/recherche-innovation/mindandact/visatt)
* [Home control](https://gitlab.oneforge.altran-onesoftware.fr/france/recherche-innovation/mindandact/homecontrol)
* [Agency](https://gitlab.oneforge.altran-onesoftware.fr/france/recherche-innovation/mindandact/agency)
* [Perifovea](https://gitlab.oneforge.altran-onesoftware.fr/france/recherche-innovation/mindandact/perifovea)
* [Drone flying demo](https://gitlab.oneforge.altran-onesoftware.fr/france/recherche-innovation/mindandact/drone.demo)
* [VR BCI project](https://gitlab.oneforge.altran-onesoftware.fr/france/recherche-innovation/mindandact/ssvep_static_online)

It contains the folllowing algorithms to classify the SSVEP brain responses:
* EEGNet convolutional architecture. The architecture is [here](eegnet.py), for more details, please read [this paper](docs/eegnet_preprint.pdf)
-------------
The repository contains the possibility to track your experiments with [Neptune.AI](https://neptune.ai/product/experiment-tracking).
Please find the instructions [here](lib/tracking/README.md)


## System Requirements

Python 3 (excessively tested on Python3.10) and all libraries and packages listed in [requirements.txt](config/requirements.txt). Hardware recommendations include a multi-threading CPU (e.g. Intel's i5/i7),at least 8GB of RAM and, most importantly the CUDA-enabled GPU (installation tips [here](https://www.tensorflow.org/install/gpu)). The code of this demo should be runnable under all platforms, and was developed mainly under Linux (default platform) and Windows 10

Deep learning is running under Tensorflow backend

Folder- and file-naming conventions are platform-dependent. Please use with care.

The project's code has been developed using VSCode and JetBrains DataSpell for Linux and for Windows.

### Creating protected virtual environment

(If you have already created a virtual environment <maa-env>, you can skip this step)

You can install create a virtual environment either using `venv` library with the following commands:

```
   cd <name-of-the-cloned-repo-folder>
   python -m venv maa-env
   source maa-env/bin/activate
   pip install -r requirements.txt
  ```

Or using `conda` package manager with the following commands (this will fix also the Python version):

```
   cd <name-of-the-cloned-repo-folder>
   conda env create -f environment.yml
   conda activate maa-env
  ```

### Use

Please refer to [example_notebook](example_notebook.ipynb) for example use (based on EEGNet).
If you prefer to use script and to see the example Neptune tracking, please refer
to [example_run_script](example_run_script.py).

Note that the parameters taken there are already hypertuned.

To make it work, have
[MAA data management repo](https://gitlab.oneforge.altran-onesoftware.fr/france/recherche-innovation/mindandact/maa-data-manager)
cloned for smooth data loading as well as any dataset.