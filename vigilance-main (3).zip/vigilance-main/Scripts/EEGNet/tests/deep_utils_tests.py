# version 1.0.2
import unittest
import os, sys, shutil
import numpy as np
from matplotlib import pyplot as plt
from sklearn.metrics._plot.confusion_matrix import ConfusionMatrixDisplay


# Constants
dropoutRate = 0.1
F1 = 12
D = 8
F2 = 96
norm_rate = 0.25
dropoutType = 'Dropout'
kernLength = 125

rootFolder = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, rootFolder)
import lib.models.deep_utils as du

class ParamsTestCase(unittest.TestCase):
    paramsDefault = du.Params(dropoutRate=dropoutRate, F1=F1, D=D, F2=F2,
                              norm_rate=norm_rate, dropoutType=dropoutType,
                              kernLength=kernLength)
    paramsCustom = du.Params(nchannels=3, wdur=3, samplingRate=100, D=10,
                             dropoutRate=dropoutRate, F1=F1, F2=F2,
                             norm_rate=norm_rate, dropoutType=dropoutType,
                             kernLength=kernLength)
    paramsAddSmth = du.Params(a=1, b=2, c=3)

    def test_params_it_right_class(self):
        self.assertIsInstance(ParamsTestCase.paramsDefault, du.Params)

    def test_params_default_values(self):
        self.assertEqual(ParamsTestCase.paramsDefault.chans, 8)
        self.assertEqual(ParamsTestCase.paramsDefault.wdur, 1)
        self.assertEqual(ParamsTestCase.paramsDefault.samplingRate, 250)
        self.assertEqual(ParamsTestCase.paramsDefault.samples, 250)
        self.assertEqual(ParamsTestCase.paramsDefault.kernLength, 125)
        self.assertEqual(ParamsTestCase.paramsDefault.dropoutRate, 0.1)
        self.assertEqual(ParamsTestCase.paramsDefault.F1, 12)
        self.assertEqual(ParamsTestCase.paramsDefault.D, 8)
        self.assertEqual(ParamsTestCase.paramsDefault.F2, 96)
        self.assertEqual(ParamsTestCase.paramsDefault.norm_rate, 0.25)
        self.assertEqual(ParamsTestCase.paramsDefault.dropoutType, 'Dropout')

    def test_params_custom_values(self):
        self.assertEqual(ParamsTestCase.paramsCustom.chans, 8)
        self.assertEqual(ParamsTestCase.paramsCustom.wdur, 3)
        self.assertEqual(ParamsTestCase.paramsCustom.samplingRate, 100)
        self.assertEqual(ParamsTestCase.paramsCustom.samples, 300)
        self.assertEqual(ParamsTestCase.paramsCustom.dropoutRate, 0.1)
        self.assertEqual(ParamsTestCase.paramsCustom.F1, 12)
        self.assertEqual(ParamsTestCase.paramsCustom.D, 10)
        self.assertEqual(ParamsTestCase.paramsCustom.F2, 96)
        self.assertEqual(ParamsTestCase.paramsCustom.norm_rate, 0.25)
        self.assertEqual(ParamsTestCase.paramsCustom.dropoutType, 'Dropout')

    def test_params_add_values(self):
        self.assertEqual(ParamsTestCase.paramsAddSmth.chans, 8)
        self.assertEqual(ParamsTestCase.paramsAddSmth.wdur, 1)
        self.assertEqual(ParamsTestCase.paramsAddSmth.samplingRate, 250)
        self.assertEqual(ParamsTestCase.paramsAddSmth.samples, 250)
        self.assertEqual(ParamsTestCase.paramsAddSmth.a, 1)
        self.assertEqual(ParamsTestCase.paramsAddSmth.b, 2)
        self.assertEqual(ParamsTestCase.paramsAddSmth.c, 3)


class NameOutputFoldersTestCase(unittest.TestCase):
    curDir = os.getcwd()
    testDirEEGModel1 = os.path.join(curDir, "eegnet_model5")
    testDirEEGModel2 = os.path.join(curDir, "eegnet_model2")
    testDirEEGResult = os.path.join(curDir, "eegnet_results7")
    testDirEEGLog = os.path.join(curDir, "eegnet_log3")
    testDirRandom = os.path.join(curDir, "random_pattern1h__23")

    def setUp(self):
        os.mkdir(NameOutputFoldersTestCase.testDirEEGModel1)
        os.mkdir(NameOutputFoldersTestCase.testDirEEGModel2)
        os.mkdir(NameOutputFoldersTestCase.testDirEEGResult)
        os.mkdir(NameOutputFoldersTestCase.testDirEEGLog)
        os.mkdir(NameOutputFoldersTestCase.testDirRandom)

    def test_if_find_dir_gives_zero_if_no_matching_folders_are_found(self):
        output = du.find_dir_number(NameOutputFoldersTestCase.curDir, 'nofolder')
        self.assertEqual(output, 0)

    def test_find_dir_number_finds_eegnet_model(self):
        output = du.find_dir_number(NameOutputFoldersTestCase.curDir,
                                    searchedPattern="eegnet_model")
        self.assertEqual(output, 5)

    def test_find_dir_number_finds_eegnet_log(self):
        output = du.find_dir_number(NameOutputFoldersTestCase.curDir,
                                    searchedPattern="eegnet_log")
        self.assertEqual(output, 3)

    def test_find_dir_number_finds_eegnet_results(self):
        output = du.find_dir_number(NameOutputFoldersTestCase.curDir,
                                    searchedPattern="eegnet_results")
        self.assertEqual(output, 7)

    def test_find_dir_number_finds_random_pattern(self):
        output = du.find_dir_number(NameOutputFoldersTestCase.curDir,
                                    searchedPattern="random_pattern1h__")
        self.assertEqual(output, 23)

    def test_find_dir_number_gives_error_if_after_pattern_no_int(self):
        output = du.find_dir_number(NameOutputFoldersTestCase.curDir,
                                    searchedPattern="random_pattern")
        self.assertEqual(output, 0)

    def test_name_output_folder_gives_correct_predefined_name(self):
        output = du.name_output_folder(folder='folderName',
                                        nameModel='rnn', typeFolder='model')
        self.assertEqual(output, os.path.join(NameOutputFoldersTestCase.curDir,
                                              'folderName'))

    def test_name_output_folder_counts_right_model(self):
        output = du.name_output_folder(nameModel='eegnet', typeFolder='model')
        self.assertEqual(output, os.path.join(NameOutputFoldersTestCase.curDir,
                                              'eegnet_model6'))

    def test_name_output_folder_counts_right_results(self):
        output = du.name_output_folder(nameModel='eegnet', typeFolder='results')
        self.assertEqual(output, os.path.join(NameOutputFoldersTestCase.curDir,
                                              'eegnet_results8'))

    def test_name_output_folder_counts_right_log(self):
        output = du.name_output_folder(nameModel='eegnet', typeFolder='log')
        self.assertEqual(output, os.path.join(NameOutputFoldersTestCase.curDir,
                                              'eegnet_log4'))

    def test_name_output_folder_if_no_pattern_was_found(self):
        output = du.name_output_folder(nameModel='random', typeFolder='something')
        self.assertEqual(output, os.path.join(NameOutputFoldersTestCase.curDir,
                                              'random_something'))

    def test_name_output_folder_if_no_pattern_was_found_no_name(self):
        output = du.name_output_folder(typeFolder='something')
        self.assertEqual(output, os.path.join(NameOutputFoldersTestCase.curDir,
                                              '_something'))

    def test_name_output_folder_if_no_pattern_was_found_no_type(self):
        output = du.name_output_folder(nameModel='something', typeFolder='')
        self.assertEqual(output, os.path.join(NameOutputFoldersTestCase.curDir,
                                              'something_'))

    def test_name_output_folder_if_no_pattern_was_found_nothing(self):
        with self.assertRaises(ValueError):
            du.name_output_folder(nameModel='', typeFolder='')

    def tearDown(self):
        shutil.rmtree(NameOutputFoldersTestCase.testDirEEGModel1)
        shutil.rmtree(NameOutputFoldersTestCase.testDirEEGModel2)
        shutil.rmtree(NameOutputFoldersTestCase.testDirEEGResult)
        shutil.rmtree(NameOutputFoldersTestCase.testDirEEGLog)
        shutil.rmtree(NameOutputFoldersTestCase.testDirRandom)


class ManageFoldersTestCase(unittest.TestCase):
    curDir = os.getcwd()

    def setUp(self):
        self.dirModelNoIn, self.dirLogNoIn, self.dirResultNoIn = du.manage_folders()
        self.dirModelOnlyModel, self.dirLogOnlyModel, self.dirResultOnlyModel = \
            du.manage_folders(dirModel='damngreatmodel')
        self.dirModelOnlyLog, self.dirLogOnlyLog, self.dirResultOnlyLog = \
            du.manage_folders(dirLog='damngreatLog')
        self.dirModelOnlyResults, self.dirLogOnlyResults, self.dirResultOnlyResults = \
            du.manage_folders(dirResult='damngreatresults')
        self.dirModelEEGNet, self.dirLogEEGNet, self.dirResultEEGNet = \
            du.manage_folders(nameModel='eegnet')
        self.dirModelEEGNet1, self.dirLogEEGNet1, self.dirResultEEGNet1 = \
            du.manage_folders(nameModel='eegnet') # to_check_the_numbering

    def test_no_inputs_model_output(self):
        self.assertEqual(self.dirModelNoIn, os.path.join(ManageFoldersTestCase.curDir,
                                                         'defaultnet_model'))

    def test_no_inputs_model_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'defaultnet_model')))

    def test_no_inputs_log_output(self):
        self.assertEqual(self.dirLogNoIn, os.path.join(ManageFoldersTestCase.curDir,
                                                         'defaultnet_log'))

    def test_no_inputs_log_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'defaultnet_log')))

    def test_no_inputs_results_output(self):
        self.assertEqual(self.dirResultNoIn, os.path.join(ManageFoldersTestCase.curDir,
                                                       'defaultnet_results'))

    def test_no_inputs_results_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'defaultnet_results')))

    def test_onlyModel_model_output(self):
        self.assertEqual(self.dirModelOnlyModel, os.path.join(ManageFoldersTestCase.curDir,
                                                         'damngreatmodel'))

    def test_onlyModel_log_output(self):
        self.assertEqual(self.dirLogOnlyModel, os.path.join(ManageFoldersTestCase.curDir,
                                                         'defaultnet_log1'))

    def test_onlyModel_results_output(self):
        self.assertEqual(self.dirResultOnlyModel, os.path.join(ManageFoldersTestCase.curDir,
                                                            'defaultnet_results1'))

    def test_onlyModel_model_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'damngreatmodel')))

    def test_onlyLog_model_output(self):
        self.assertEqual(self.dirModelOnlyLog, os.path.join(ManageFoldersTestCase.curDir,
                                                         'defaultnet_model1'))

    def test_onlyLog_log_output(self):
        self.assertEqual(self.dirLogOnlyLog, os.path.join(ManageFoldersTestCase.curDir,
                                                            'damngreatLog'))

    def test_onlyLog_results_output(self):
        self.assertEqual(self.dirResultOnlyLog, os.path.join(ManageFoldersTestCase.curDir,
                                                            'defaultnet_results2'))

    def test_onlyLog_model_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'damngreatLog')))

    def test_onlyResult_model_output(self):
        self.assertEqual(self.dirModelOnlyResults, os.path.join(ManageFoldersTestCase.curDir,
                                                            'defaultnet_model2'))

    def test_onlyResult_log_output(self):
        self.assertEqual(self.dirLogOnlyResults, os.path.join(ManageFoldersTestCase.curDir,
                                                          'defaultnet_log2'))

    def test_onlyResult_results_output(self):
        self.assertEqual(self.dirResultOnlyResults, os.path.join(ManageFoldersTestCase.curDir,
                                                             'damngreatresults'))

    def test_onlyResult_model_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'damngreatresults')))

    def test_eegnet_as_model_output(self):
        self.assertEqual(self.dirModelEEGNet, os.path.join(ManageFoldersTestCase.curDir,
                                                         'eegnet_model'))

    def test_eegnet_as_model_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'eegnet_model')))

    def test_eegnet_as_log_output(self):
        self.assertEqual(self.dirLogEEGNet, os.path.join(ManageFoldersTestCase.curDir,
                                                       'eegnet_log'))

    def test_eegnet_as_log_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'eegnet_log')))

    def test_eegnet_as_results_output(self):
        self.assertEqual(self.dirResultEEGNet, os.path.join(ManageFoldersTestCase.curDir,
                                                           'eegnet_results'))

    def test_eegnet_as_results_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'eegnet_results')))

    def test_eegnet_as_model_output_second(self):
        self.assertEqual(self.dirModelEEGNet1, os.path.join(ManageFoldersTestCase.curDir,
                                                           'eegnet_model1'))

    def test_eegnet_as_model_folder_exists_second(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'eegnet_model1')))

    def test_eegnet_as_log_output_second(self):
        self.assertEqual(self.dirLogEEGNet1, os.path.join(ManageFoldersTestCase.curDir,
                                                         'eegnet_log1'))

    def test_eegnet_as_log_folder_exists_second(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'eegnet_log1')))

    def test_eegnet_as_results_output_second(self):
        self.assertEqual(self.dirResultEEGNet1, os.path.join(ManageFoldersTestCase.curDir,
                                                            'eegnet_results1'))

    def test_eegnet_as_results_folder_exists_second(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersTestCase.curDir,
                                                    'eegnet_results1')))

    def tearDown(self):
        shutil.rmtree(self.dirModelNoIn)
        shutil.rmtree(self.dirLogNoIn)
        shutil.rmtree(self.dirResultNoIn)
        shutil.rmtree(self.dirModelOnlyModel)
        shutil.rmtree(self.dirLogOnlyModel)
        shutil.rmtree(self.dirResultOnlyModel)
        shutil.rmtree(self.dirModelOnlyLog)
        shutil.rmtree(self.dirLogOnlyLog)
        shutil.rmtree(self.dirResultOnlyLog)
        shutil.rmtree(self.dirModelOnlyResults)
        shutil.rmtree(self.dirLogOnlyResults)
        shutil.rmtree(self.dirResultOnlyResults)
        shutil.rmtree(self.dirModelEEGNet)
        shutil.rmtree(self.dirLogEEGNet)
        shutil.rmtree(self.dirResultEEGNet)
        shutil.rmtree(self.dirModelEEGNet1)
        shutil.rmtree(self.dirLogEEGNet1)
        shutil.rmtree(self.dirResultEEGNet1)

class ManageFoldersSpecialTestCase(unittest.TestCase):
    curDir = os.getcwd()

    def setUp(self):
        self.dirModel, self.dirLog, self.dirResult = \
            du.manage_folders(nameModel='eegnet', dirModel='damngreatmodel',
                              dirLog='damngreatLog', dirResult='damngreatresults')

    def test_model_output(self):
        self.assertEqual(self.dirModel, os.path.join(ManageFoldersSpecialTestCase.curDir,
                                                         'damngreatmodel'))

    def test_model_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersSpecialTestCase.curDir,
                                                    'damngreatmodel')))

    def test_log_output(self):
        self.assertEqual(self.dirLog, os.path.join(ManageFoldersSpecialTestCase.curDir,
                                                       'damngreatLog'))

    def test_log_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersSpecialTestCase.curDir,
                                                    'damngreatLog')))

    def test_results_output(self):
        self.assertEqual(self.dirResult, os.path.join(ManageFoldersSpecialTestCase.curDir,
                                                          'damngreatresults'))

    def test_results_folder_exists(self):
        self.assertTrue(os.path.exists(os.path.join(ManageFoldersSpecialTestCase.curDir,
                                                    'damngreatresults')))


class ConfusionMatrixPlotterTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.curDir = os.getcwd()
        cls.confusionMatrix = np.array([[80, 20], [30, 70]])
        cls.classes = ['a', 'b']

        cls.disp, cls.outName = du.plot_confusion_matrix(cls.confusionMatrix,
                                                         cls.classes)
        cls.dispNorm, cls.outNameNorm = du.plot_confusion_matrix(cls.confusionMatrix,
                                                                 cls.classes,
                                                                 normalize=True,
                                                                 saveDir=cls.curDir)

    def test_disp_saved_has_right_name(self):
        self.assertTrue(self.outName == 'CM.png')

    def test_dispNorm_saved_has_right_name(self):
        self.assertTrue(self.outNameNorm == 'CM_norm.png')

    def test_figure_is_created(self):
        self.assertIsInstance(self.disp, ConfusionMatrixDisplay)

    def test_figure_has_labels(self):
        self.assertTrue(self.disp.ax_.get_xlabel() == 'Predicted label')
        self.assertTrue(self.disp.ax_.get_ylabel() == 'True label')

    def test_figure_has_ticklabels(self):
        self.assertTrue(self.disp.ax_.get_xticklabels()[0].get_text() == 'a')
        self.assertTrue(self.disp.ax_.get_xticklabels()[1].get_text() == 'b')
        self.assertTrue(self.disp.ax_.get_yticklabels()[0].get_text() == 'a')
        self.assertTrue(self.disp.ax_.get_yticklabels()[1].get_text() == 'b')

    def test_figure_has_correct_values(self):
        self.assertTrue(self.disp.text_[0, 0].get_text() == '80')
        self.assertTrue(self.disp.text_[0, 1].get_text() == '20')
        self.assertTrue(self.disp.text_[1, 0].get_text() == '30')
        self.assertTrue(self.disp.text_[1, 1].get_text() == '70')

    def test_figureNorm_has_correct_values(self):
        self.assertTrue(self.dispNorm.text_[0, 0].get_text() == '0.8')
        self.assertTrue(self.dispNorm.text_[0, 1].get_text() == '0.2')
        self.assertTrue(self.dispNorm.text_[1, 0].get_text() == '0.3')
        self.assertTrue(self.dispNorm.text_[1, 1].get_text() == '0.7')

    def test_dispNorm_is_saved(self):
        self.assertTrue(os.path.exists(os.path.join(self.curDir, 'CM_norm.png')))

    @classmethod
    def tearDownClass(cls):
        plt.close(cls.disp.figure_)
        plt.close(cls.dispNorm.figure_)
        os.remove(os.path.join(cls.curDir, 'CM_norm.png'))


if __name__ == '__main__':
    unittest.main()
