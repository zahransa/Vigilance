# This is not a unit test. Run it from without the unittest module

######## VERY IMPORTANT TO RUN THE TESTS ########
# 0. Verify you have the internet connection
# 1. Create a new project in Neptune Web App
# 2. Create the project named 'test' and paste it below, its name below
# 3. Copy your API token in Neptune Web App and paste it below
# 4. Uncomment the lines below (projectName and API)
# 5. Run the tests
# projectName = 'user/test'
# API = 'yourAPI'

import os, sys, shutil
import numpy as np
from tensorflow.keras import backend as K
from tensorflow.keras.utils import to_categorical

rootFolder = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, rootFolder)
import lib.tracking.neptune_wrapper as nw
from lib.models.eegnet import EEGNet
import lib.models.deep_utils as du

# if author (dbrygal) runs this get the project name and API from the .config file
if 'dbryzgal' in os.path.expanduser('~'):
    from lib.tracking.configuration import get_project_name, API
    projectName = get_project_name('test')

########################################################################
# General Parameters
SAMPLING_RATE = 250
LOWF = 5 # Low bound for filtering data
HIGHF = 40 # High bound for filtering data
TMIN = 0 # At which time point from trigger to start epoch
TMAX = 3 # At which time point from trigger to stop epoch
triggers = {'7.5Hz': 1075, '10Hz': 1010, '12Hz': 1012} # Set of events to retrieve from datasets
# number of keys in triggers will be used as a number of classes to classify
WDUR = 1 # Durations of time window to classify
TDELTA = 0.05 # Sliding window step for data augmentation
RSEED = 33 # random seed for shuffling the data
TEST_SPLIT = 0.2 # test split = testsplit
VAL_SPLIT = 0.15 # validation split = (1 - testsplit)*testsplit
# Constants
dropoutRate = 0.1
F1 = 12
D = 8
F2 = 96
norm_rate = 0.25
dropoutType = 'Dropout'
kernLength = 125

# Start the test
def main():
    curDir = os.getcwd()
    params = du.Params(dropoutRate=dropoutRate, F1=F1, D=D, F2=F2, norm_rate=norm_rate,
                       dropoutType=dropoutType, kernLength=kernLength)
    params.add_parameters(isAugment=True, isSaccade=False, lowFilter=LOWF,
                          highFilter=HIGHF, wdur=WDUR, tdelta=TDELTA, randomSeed=RSEED,
                          testSplit=TEST_SPLIT, valSplit=VAL_SPLIT,
                          triggers=triggers, tmin=TMIN, tmax=TMAX)
    eegnet = EEGNet(3, params, design='cross', dirModel='testModel',
                     dirLog='testLog', dirResult='testResult')
    trainData = np.random.rand(500, 8, 250)
    trainLabels = np.random.randint(3, size=500)
    trainLabels = to_categorical(trainLabels, 3)
    testData = np.random.rand(50, 8, 250)
    testLabels = np.random.randint(3, size=50)
    testLabels = to_categorical(testLabels, 3)
    maskSub = np.hstack((np.zeros(25), np.ones(25))) # 25 samples subject 1, 25 samples subject 2

    folderCode = os.path.expanduser('/deep_eeg/lib/models/')
    # Launch the tracker
    neptuneTracker = nw.NeptuneWrapper(projectName=projectName, api=API,
                                       dataDir='filesToTrack', params=params,
                                       sourceFiles=[os.path.join(folderCode, 'eegnet.py'),
                                                    os.path.join(folderCode, 'deep_utils.py'),
                                                    os.path.join(folderCode, 'neptune_wrapper.py'),
                                                    os.path.join(folderCode, 'requirements.txt'),
                                                    os.path.join(folderCode, 'environment.yml'),
                                                    'neptune_wrapper_tests.py'])
    neptuneTracker.create_run()
    neptuneCallback = neptuneTracker.get_tensorflow_keras_callback()

    # Train/test the model
    eegnet.compile()
    history = eegnet.train(trainData, trainLabels, 10, valSplit=0.2,
                           callbacksToAdd=neptuneCallback)
    predictions = eegnet.test(testData, batchSize=30)
    accuracy, accuracySub = eegnet.evaluate(predictions, testLabels,
                                            maskSubTest=maskSub)
    results = eegnet.evaluate_fully(predictions, testLabels, isSave=True)
    disp, cmName = du.plot_confusion_matrix(results['confusionMatrix'],
                                            ['a', 'b', 'c'],
                                            saveDir=curDir)

    # Log the results
    metricsToTrack = ['loss', 'accuracy', 'val_loss', 'val_accuracy']
    for metricName in metricsToTrack:
        neptuneTracker.log_parameters(metricName, history.history[metricName],
                                      firstLevel='train')
    neptuneTracker.log_parameters('accuracySub', accuracySub, firstLevel='test')
    for resultName in results.keys():
        neptuneTracker.log_parameters(resultName, results[resultName], firstLevel='test')
    neptuneTracker.log_artifact('confusionMatrix', cmName)
    neptuneTracker.stop_run()

    # Remove the files created by the test
    shutil.rmtree(eegnet.dirModel)
    shutil.rmtree(eegnet.dirLog)
    shutil.rmtree(eegnet.dirResult)
    os.remove(os.path.join(curDir, cmName))
    K.clear_session()


if __name__ == '__main__':
    main()
