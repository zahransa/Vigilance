# version 1.0.2

import unittest
import os, sys, shutil
import numpy as np
from numpy import ndarray, int64
import random
from tensorflow.keras import backend as K
from tensorflow.keras.utils import to_categorical
from tensorflow.python.framework import random_seed
random_seed.set_seed(42)
random.seed(42)
np.random.seed(42)


rootFolder = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, rootFolder)
from lib.models.eegnet import EEGNet
import lib.models.deep_utils as du

# Constants
dropoutRate = 0.1
F1 = 12
D = 8
F2 = 96
norm_rate = 0.25
dropoutType = 'Dropout'
kernLength = 125

# Set up variables
curDir = os.getcwd()
params = du.Params(dropoutRate=dropoutRate, F1=F1, D=D, F2=F2, norm_rate=norm_rate,
                   dropoutType=dropoutType, kernLength=kernLength)
params1 = du.Params(chans=4, wdur=2, samplingRate=100, dropoutRate=dropoutRate,
                    F1=F1, D=D, F2=F2, norm_rate=norm_rate,
                    dropoutType=dropoutType, kernLength=kernLength)
eegnet = EEGNet(3, params)
eegnet1 = EEGNet(5, params1, design='cross', dirModel='testModel',
                 dirLog='testLog', dirResult='testResult')
inputShapeRight = (None, 4, 200, 1)
outputShapeRight = (None, 5)

trainData = np.random.rand(500, 8, 250)
trainLabels = np.random.randint(3, size=500)
trainLabels = to_categorical(trainLabels, 3)
testData = np.random.rand(50, 8, 250)
testLabels = np.random.randint(3, size=50)
testLabels = to_categorical(testLabels, 3)
maskSub = np.hstack((np.zeros(25), np.ones(25))) # 25 samples subject 1, 25 samples subject 2

eegnet.compile()
history = eegnet.train(trainData, trainLabels, 10, valSplit=0.2)
predictions = eegnet.test(testData, batchSize=30)
accuracy, accuracySub = eegnet.evaluate(predictions, testLabels,
                                        maskSubTest=maskSub)
metrics = eegnet.evaluate_fully(predictions, testLabels, isSave=True)
selectedClass, predictedClasses = eegnet.decide_class(predictions, threshDecision=0.4)
potentialNone, predictedClasses = eegnet.decide_class(predictions, threshDecision=0.99)
eegnet.save_parameters(nameFile='testParams')

class EEGNetTestCase(unittest.TestCase):

    def test_number_classes(self):
        self.assertEqual(eegnet.nb_classes, 3)

    def test_params_it_right_class(self):
        self.assertIsInstance(eegnet.params, du.Params)

    def test_design(self):
        self.assertEqual(eegnet.design, 'within')

    def test_name_model_folder(self):
        self.assertEqual(eegnet.dirModel, os.path.join(curDir, 'eegnet_model'))

    def test_name_log_folder(self):
        self.assertEqual(eegnet.dirLog, os.path.join(curDir, 'eegnet_log'))

    def test_name_result_folder(self):
        self.assertEqual(eegnet.dirResult, os.path.join(curDir, 'eegnet_results'))

    def test_number_classes1(self):
        self.assertEqual(eegnet1.nb_classes, 5)

    def test_design1(self):
        self.assertEqual(eegnet1.design, 'cross')

    def test_name_model_folder1(self):
        self.assertEqual(eegnet1.dirModel, os.path.join(curDir, 'testModel'))

    def test_name_log_folder1(self):
        self.assertEqual(eegnet1.dirLog, os.path.join(curDir, 'testLog'))

    def test_name_result_folder1(self):
        self.assertEqual(eegnet1.dirResult, os.path.join(curDir, 'testResult'))

    def test_gives_error_if_design_is_not_within_or_cross(self):
        with self.assertRaises(ValueError):
            EEGNet(3, params, design='wrong')

    def test_gives_error_if_dropoutType_is_not_SpatialDropout2D_or_Dropout(self):
        with self.assertRaises(ValueError):
            params = du.Params(dropoutType='wrong')
            EEGNet(3, params)

    def test_model_is_created(self):
        self.assertIsNotNone(eegnet.model)

    def test_input_layer(self):
        self.assertEqual(tuple(eegnet1.model.input.shape), inputShapeRight)

    def test_output_layer(self):
        self.assertEqual(tuple(eegnet1.model.output.shape), outputShapeRight)

    def test_loss_descreases(self):
        self.assertLess(history.history['loss'][-1], history.history['loss'][0])

    def test_val_loss_descreases(self):
        self.assertLess(history.history['val_loss'][-1],
                        history.history['val_loss'][0])

    def test_accuracy_increases(self):
        self.assertGreater(history.history['accuracy'][-1],
                           history.history['accuracy'][0])

    def test_val_accuracy_increases(self):
        self.assertGreater(history.history['val_accuracy'][-1],
                           history.history['val_accuracy'][0])

    def test_checkpoint_are_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirModel,
                                                    'checkpoint')))

    def test_losses_are_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirResult,
                                                    'loss.csv')))

    def test_val_losses_are_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirResult,
                                                    'val_loss.csv')))

    def test_tensorboard_stuff_is_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirLog,
                                                    'train')))

    def test_predictions_shape(self):
            self.assertEqual(predictions.shape, (50, 3))

    def test_accuracy_is_number(self):
        self.assertIsInstance(accuracy, float)

    def test_accuracy_is_between_0_and_1(self):
        self.assertGreaterEqual(accuracy, 0)
        self.assertLessEqual(accuracy, 1)

    def test_accuracy_sub_is_list(self):
        self.assertIsInstance(accuracySub, list)

    def test_accuracy_sub_has_as_many_elements_as_unique_num_in_maskSub(self):
        self.assertEqual(len(accuracySub), 2)

    def test_accuracy_sub_is_between_0_and_1(self):
        for acc in accuracySub:
            self.assertGreaterEqual(acc, 0)
            self.assertLessEqual(acc, 1)

    def test_accuracy_sub_is_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirResult,
                                                    'accuraciesSub.csv')))

    def test_metrics_is_dict(self):
        self.assertIsInstance(metrics, dict)

    def test_metrics_has_accuracy_in_right_format(self):
        self.assertIsInstance(metrics['accuracy'], float)
        self.assertGreaterEqual(metrics['accuracy'], 0)
        self.assertLessEqual(metrics['accuracy'], 1)

    def test_metrics_has_confusion_matrix_in_right_format(self):
        self.assertIsInstance(metrics['confusionMatrix'], np.ndarray)
        self.assertEqual(metrics['confusionMatrix'].shape, (3, 3))

    def test_metrics_has_f1_score_in_right_format(self):
        self.assertIsInstance(metrics['f1-score'], float)
        self.assertGreaterEqual(metrics['f1-score'], 0)
        self.assertLessEqual(metrics['f1-score'], 1)

    def test_metrics_has_precision_in_right_format(self):
        self.assertIsInstance(metrics['precision'], float)
        self.assertGreaterEqual(metrics['precision'], 0)
        self.assertLessEqual(metrics['precision'], 1)

    def test_metrics_has_recall_in_right_format(self):
        self.assertIsInstance(metrics['recall'], float)
        self.assertGreaterEqual(metrics['recall'], 0)
        self.assertLessEqual(metrics['recall'], 1)

    def test_metrics_accuracy_is_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirResult,
                                                    'accuracy.csv')))

    def test_metrics_confusion_matrix_is_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirResult,
                                                    'confusionMatrix.csv')))

    def test_metrics_f1score_is_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirResult,
                                                    'f1-score.csv')))

    def test_metrics_precision_is_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirResult,
                                                    'precision.csv')))

    def test_metrics_recall_is_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirResult,
                                                    'recall.csv')))

    def test_decide_class_gives_class(self):
        self.assertIsInstance(selectedClass, int64)

    def test_decide_class_gives_class_between_0_and_2(self):
        self.assertGreaterEqual(selectedClass, 0)
        self.assertLessEqual(selectedClass, 2)

    def test_decide_class_gives_list_of_predicted_classes(self):
        self.assertIsInstance(predictedClasses, ndarray)

    def test_decide_class_gives_list_of_predicted_classes_with_right_shape(self):
        self.assertEqual(np.array(predictedClasses).shape, (50,))

    def test_decide_class_gives_list_of_predicted_classes_with_right_values(self):
        self.assertGreaterEqual(np.min(predictedClasses), 0)
        self.assertLessEqual(np.max(predictedClasses), 2)

    def test_decide_class_gives_none_in_case_of_no_decision(self):
        self.assertIsNone(potentialNone)

    def test_params_are_saved(self):
        self.assertTrue(os.path.exists(os.path.join(eegnet.dirLog,
                                                    'testParams.json')))

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(eegnet.dirModel)
        shutil.rmtree(eegnet.dirLog)
        shutil.rmtree(eegnet.dirResult)
        shutil.rmtree(eegnet1.dirModel)
        shutil.rmtree(eegnet1.dirLog)
        shutil.rmtree(eegnet1.dirResult)
        K.clear_session()


if __name__ == '__main__':
    unittest.main()
