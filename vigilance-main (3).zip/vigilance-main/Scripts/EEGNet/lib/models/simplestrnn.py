# Description: simpleRNN class derived from defaultnet of Mind and Act
# #-Author: Dmitrii Bryzgalov (dmitrii.bryzgalov@capgemini.com)

# Version 1.0.2
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Activation, Permute, Dropout
from tensorflow.keras.layers import SimpleRNN
from tensorflow.keras.layers import Input, Flatten
from tensorflow.keras.constraints import max_norm

from .defaultnet import ANNet
from .deep_utils import manage_folders

class RNN(ANNet):
    def __init__(self, nb_classes, Params, design='within',
                 dirModel=None, dirLog=None, dirResult=None):

        """ Keras Implementation of simple one layer RNN

        Inputs:

        nb_classes      : int, number of classes to classify
        Params          : obj, parameters for EEGNet
        design          : str, 'within' or 'cross'; default='within'
        dirModel        : path, to save the weights of the model
                          default - 'eegnet_modelX' in the current folder
        dirLogs         : path, path to save the tensorboard log and other logs;
                          default=None
        dirResults:     : path, to save the results; default - 'eegnet_results'
                          in the current folder
        """

        ### Network parameters
        self.nb_classes = nb_classes
        self.params = Params
        self.design = design
        if self.design != 'within' and self.design != 'cross':
            raise ValueError('design must be either "within" or "cross"')

        ##################################################################
        input1   = Input(shape=(self.params.samples, self.params.chans))
        blockrnn = SimpleRNN(self.params.samples, input_shape=(self.params.chans,
                                                       self.params.samples, 1),
                             use_bias=True,
                             recurrent_dropout=self.params.dropoutRate)(input1)
        '''
        dense  = Dense(self.nb_classes, name='dense',
                 kernel_constraint=max_norm(Params.norm_rate))(blockrnn)
        softmax  = Activation('softmax', name='softmax')(dense)

        self.model = Model(inputs=input1, outputs=softmax)
        '''
        # Nicolai changed to sigmoid
        dense  = Dense(1, name='dense',
                 kernel_constraint=max_norm(Params.norm_rate))(blockrnn)
        sigmoid  = Activation('sigmoid', name='sigmoid')(dense)

        self.model = Model(inputs=input1, outputs=sigmoid)

        ### Folders (should be in the end because manage_folders creates folders
        # if there is an error upsteam, the folders avoid to be created)
        _dirModel, _dirLog, _dirResult = manage_folders(nameModel=RNN.__name__.lower(),
                                                        dirModel=dirModel,
                                                        dirLog=dirLog,
                                                        dirResult=dirResult)
        self.dirModel = _dirModel
        self.dirLog = _dirLog
        self.dirResult = _dirResult