# Description: Utility functions for deep learning classifiers at Mind and Act
# #-Author: Dmitrii Bryzgalov (dmitrii.bryzgalov@capgemini.com)

# version 1.0.2
import os, glob
import numpy as np
from tensorflow.keras.callbacks import Callback
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay

class Params:
    def __init__(self, chans=8, wdur=1, samplingRate=250, **kwargs):

        """ Parameters for Keras Implementation of your ANN. Add as many parameters
        as you want as optional keyword arguments.
        They intended to pass in parameters argument of your model class and be
        used like that: model.params.paramName
        I added some parameters as an example:

        chans           : number of channels and time points in the EEG data;
                          default: 8
        wdur            : duration of the analyzed window in seconds; default: 1
        samplingRate    : sampling rate of the EEG data in Hz; default: 250

        """

        self.chans = chans
        self.wdur = wdur
        self.samplingRate = samplingRate
        self.samples = int(self.wdur*self.samplingRate)

        for key, value in kwargs.items():
            self.__dict__[key] = value

    def add_parameters(self, **kwargs):

        for key, value in kwargs.items():
            self.__dict__[key] = value


######### AUXILIARY default net class functions #########
def manage_folders(nameModel='defaultnet', dirModel=None, dirLog=None,
                   dirResult=None):
    """ This function creates folders supporting the current instance of the
    model.

    Inputs:

    nameModel       : str, name of the model to be used in the folder name
    dirModel        : path, to save the weights of the model
                        default - 'eegnet_modelX' in the current folder
    dirLogs         : path, path to save the tensorboard log and other logs;
                        default=None
    dirResults:     : path, to save the results; default - 'eegnet_results'
                        in the current folder

    Outputs:

    dirModel        : path, to save the weights of the model
    dirLogs         : path, to save the tensorboard log and other logs
    dirResults:     : path, to save the results
    """

    folders = []
    # Model weights
    dirModel = name_output_folder(folder=dirModel, nameModel=nameModel,
                                    typeFolder='model')
    folders.append(dirModel)
    # Model log
    dirLog = name_output_folder(folder=dirLog, nameModel=nameModel,
                                  typeFolder='log')
    folders.append(dirLog)
    # Model results
    dirResult = name_output_folder(folder=dirResult, nameModel=nameModel,
                                     typeFolder='results')
    folders.append(dirResult)

    # Create folders
    for folder in folders:
        if not os.path.isdir(folder):
            os.makedirs(folder)

    return dirModel, dirLog, dirResult


def name_output_folder(folder=None, nameModel='', typeFolder='model'):
    """ This function creates a folder name to save the artefacts of the current
    instance of the model.

    Inputs:

    folder          : path, either to act as a output folder or None to create
                      a new folder matching the name of the model and the type
                      of the artefact
    nameModel       : str, name of the model to be used in the folder name
    typeFolder      : path, type of the artefacts to include in the folder name

    Outputs:

    folderOut       : path, if folder is None, it creates a new folder matching
                      the following pattern 'nameModel_typeFolderX' where X is
                      the number of the folder in the current directory. Otherwise,
                      it returns the folder path.

    """
    curFolder = os.getcwd()
    if folder is None:
        searchedPattern = f'{nameModel.lower()}_{typeFolder}'
        if searchedPattern == '_':
            raise ValueError('Please provide a name for the model')
        else:
            if not glob.glob(os.path.join(curFolder, f'{searchedPattern}*')):
                folderOut = os.path.join(curFolder, searchedPattern)
            else:
                n = find_dir_number(curFolder, searchedPattern) + 1
                folderOut = os.path.join(os.getcwd(), f'{searchedPattern}{n}')
    else:
        folderOut = os.path.join(curFolder, folder)

    return folderOut

def find_dir_number(path, searchedPattern):
    """ This function finds the folder number in the current directory.
    Searches for the pattern 'searchedPatternX' where X is the number
    of the folder in the current directory and returns the maximum number X.
    Im case of no match, returns 0.

    Inputs:

    folder          : path, where to look for the model folder
    searchedPattern : str, start of the folder name; a number is expected after
                      the pattern in the name of the folder

    Outputs:

    num             : int, maximum number of the folder in the current directory
    """

    numbersEncountered = [0] # if no folder is found, return 0
    for filename in os.listdir(path):
        name, _ = os.path.splitext(filename)
        if name.startswith(searchedPattern):
            try:
                numbersEncountered.append(int(name[len(searchedPattern):]))
            except ValueError:
                if name[len(searchedPattern):] != '':
                    print(f'Not a number detected after the pattern '
                          f'{searchedPattern} during {find_dir_number.__name__}() use')
    return max(numbersEncountered)
######### AUXILIARY default net class functions #########


### Plot functions ###
def plot_confusion_matrix(confusionMatrix, classesNames, normalize=False,
                          saveDir=None):
    if normalize:
        normalizer = np.sum(confusionMatrix, axis=1)
        outName = f'CM_norm.png'
    else:
        normalizer = 1
        outName = 'CM.png'

    disp = ConfusionMatrixDisplay(confusionMatrix / normalizer,
                                  display_labels=classesNames)
    disp.plot()
    if saveDir is not None:
        plt.savefig(os.path.join(saveDir, outName))

    return disp, outName
### Plot functions ###

### LRSchedulerFixed & LRSchedulerExpDecay: Added Nicolai from Dimitrii's old code version

class LRSchedulerFixed:
    '''
    This class implements fixed learning rate scheduler to be used by keras callback
    '''

    def __init__(self, initialLR):
        '''Constructor

        Inputs:     initialLR (float or int learning rate(s) to start
        '''

        if isinstance(initialLR, (float, int)):
            self.initialLR = initialLR
        else:
            raise ValueError('initialLR must be a scalar')


    def step(self, epoch, lr):
        '''Returns learning rate for a given epoch using fixed values

        Inputs:     epoch (int), current epoch
                    lr (float), current learning rate

        Outputs:    self.initialLR (float), initial learning rate
        '''

        return self.initialLR


class LRSchedulerExpDecay(LRSchedulerFixed):
    '''
    This class implements exponential decay learning rate scheduler to be used
    by keras callback
    '''

    def __init__(self, initialLR, startDecay=10, decayRate=-0.01):
        '''Constructor

        Inputs:     initialLR (float or int learning rate(s) to start
                    startDecay (int), epoch to start decaying
                    decayRate (float), rate of decay
        '''
        super(LRSchedulerExpDecay, self).__init__(initialLR)
        if isinstance(startDecay, int) and startDecay > 0:
            self.startDecay = startDecay
        else:
            raise ValueError('startDecay must be a positive integer')
        self.decayRate = decayRate

    def step(self, epoch, lr):
        '''Returns learning rate for a given epoch using exponential decay

        Inputs:     epoch (int), current epoch
                    lr (float), current learning rate

        Outputs:    lr (float), new learning rate
        '''

        if epoch == 0:
            return self.initialLR
        if epoch < self.startDecay-1:
            return lr
        else:
            return lr * np.exp(self.decayRate)


class EarlyStoppingAtBestEpoch(Callback): # TODO Adapt to our task completely
    """Stop training when the loss is at its min, i.e. the loss stops decreasing.
    Taken from
    https://www.tensorflow.org/guide/keras/custom_callback#early_stopping_at_minimum_loss

    Arguments:
        patience: Number of epochs to wait after min has been hit. After this
        number of no improvement, training stops.
    """

    def __init__(self, patience=0):
        super(EarlyStoppingAtBestEpoch, self).__init__()
        self.patience = patience
        # best_weights to store the weights at which the minimum loss occurs.
        self.best_weights = None

    def on_train_begin(self, logs=None):
        # The number of epoch it has waited when loss is no longer minimum.
        self.wait = 0
        # The epoch the training stops at.
        self.stopped_epoch = 0
        # Initialize the best as infinity.
        self.best = np.Inf

    def on_epoch_end(self, epoch, logs=None):
        current = logs.get("loss")
        if np.less(current, self.best):
            self.best = current
            self.wait = 0
            # Record the best weights if current results is better (less).
            self.best_weights = self.model.get_weights()
        else:
            self.wait += 1
            if self.wait >= self.patience:
                self.stopped_epoch = epoch
                self.model.stop_training = True
                print("Restoring model weights from the end of the best epoch.")
                self.model.set_weights(self.best_weights)

    def on_train_end(self, logs=None):
        if self.stopped_epoch > 0:
            print("Epoch %05d: early stopping" % (self.stopped_epoch + 1))


