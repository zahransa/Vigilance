# Description: template for any possible ANN class at Mind and Act
# Template method patten was used here
# https://refactoring.guru/design-patterns/template-method/python/example
# #-Author: Dmitrii Bryzgalov (dmitrii.bryzgalov@capgemini.com)

# version 1.0.2
import os, glob
import pandas as pd
import numpy as np
import json
from abc import ABC, abstractmethod
# Import sklearn metrics
from sklearn.metrics import accuracy_score, f1_score, precision_score
from sklearn.metrics import recall_score, confusion_matrix
# Import tensorflow classes
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from tensorflow.keras.callbacks import TensorBoard
from tensorflow.keras.optimizers.experimental import Nadam
from tensorflow.keras.callbacks import LearningRateScheduler # added Nicolai
from tensorflow.keras.optimizers import get as get_optimizer # added Nicolai


# CONSTANTS
EPOCH_TOLERANCE_CROSS = 2
EPOCH_TOLERANCE_WITHIN = 4

class ANNet(ABC):
    """ This is the abstract class for any ANN model under tensorflow 2.
    The concrete class should implement the following methods:
    __init__ with the model defined, number of classes, parameters and
    experimental design
    """

    @abstractmethod # obligatory to implement in concrete class
    def __init__(self, nb_classes, Params):
        pass

    #def compile(self, loss='categorical_crossentropy', optimizer='nadam'):
    def compile(self, loss='binary_crossentropy', learning_rate=0.01, optimizer='nadam'):    # modified Nicolai

        """ This function compliles this instance of the ANN in question.
        Place to choose the loss function and the optimizer

        Inputs:

        loss            : str, type of loss to be used;
                          default='categorical_crossentropy'
        optimizer       : str, optimizer to be used; default='nadam'
        """

        #self.model.compile(loss=loss, optimizer=optimizer, metrics=['accuracy'])

        optimizer = Nadam(learning_rate=learning_rate)
        self.model.compile(loss=loss, optimizer=optimizer, metrics=['accuracy'])   # modified Nicolai

    ### Added Nicolai from Dimitrii's old code version
    def fix_learning_rate_schedule(self, lrSchedulerClass=None, **kwargs):
        ''' This function fixes the learning rate schedule for the model training
        in self.lrScheduler class if one wants custom schedule

        Inputs:     lrSchedulerClass : class, learning rate scheduler class (could
                    be any class inherited from deep_utils.LRSchedulerFixed)
                    **kwargs        : keyword arguments for the lrScheduler:
                        'initLR'        : float, initial learning rate to overwrite
                        the default one from the optimizer
                        other arguments are specific for the lrScheduler class

        Outputs:    None
        '''

        if 'initLR' in kwargs:
            setattr(self, 'initLR', kwargs['initLR'])
            kwargs.pop('initLR')

        if lrSchedulerClass is not None:
            self.lrScheduler = lrSchedulerClass(self.initLR, **kwargs)

    def train(self, dataTrain, labelsTrain, nEpochs, batchSize=30, valSplit=0,
              valData=None, earlyStopping=False, isSave=True, callbacksToAdd=None):

        """This function train the network with the provided neural data.

        Training consists of optimizing weights of the network such that the
        prediction accuracy on the training set would be as close as possible
        to the real data.

        Training proceeds by epochs. Epoch is one full iteration of weights
        optimization over entire dataset. Usually, one needs to iterate several
        times (train for several epochs) in order to achieve good prediction
        rates.

        Within one epoch, one optimization step is made on a batch of data:
        number of instances grouped together. Thus, one training epoch consists
        of <n_instances/batch_size> optimization steps. Usually, batch size is
        treated as hyperparameter (it is not obvious how many instances a certain
        optimization algorithm will need for the best performance but the rule
        of thumb for the gradient descent type of optimization is to put as much
        data in one batch as fits in the memory of your GPU).

        When very good performance on the train dataset cannot be reproduced on
        the test dataset (on which one never trained the network), one calls it
        overfitting. To combat this lack of generalization, we can use various
        techniques. One of them is called early stopping: we can set aside a
        part of train dataset, and monitor performance metrics each epoch on
        this 'validation' dataset. Once validation metrics stop to improve, we
        can stop training.

        Inputs:

        dataTrain       : np.array, of shape (time_windows x channels x time),
                          which contains neural data to be trained on
        labelsTrain     : np.array, labels associated with data Train. If model
                          is compiled with 'categorical_crossentropy' loss
                          function, labelsTrain is of shape (time_windows x
                          classes) with 1 in the corresponding column if this
                          window belongs to this class, 0 otherwise
        nEpochs         : int, maximum number of epochs to be trained for
        batchSize       : int, number of time windows to be packed in one batch;
                          default=30
        valSplit        : float, in range between 0 and 1 - a proportion of
                          dataTrain to be held from training to calculate
                          validation metrics; default=0
        valData         : tuple, (dataVal, labelsVal) - data and labels to serve
                          as validation dataset; default=None. IMPORTANT: if both
                          valSplit and valData are provided, valData will be used
        earlyStopping   : bool, if True stops the training when the validation
                          loss stops to improve; default=False
        isSave          : bool, if True saves loss and (if exists) validation
                          loss in results folder; default=True
        callbacksToAdd  : list, list of valid tensorflow callbacks to be added
                          to the default ones (ModelCheckpoint, Tensorboard and
                          EarlyStopping if applicable); default=None

        Outputs:

        history         : obj, tensorflow history of training
        """

        self.create_callbacks(valSplit=valSplit, valData=valData,
                              earlyStopping=earlyStopping, callbacksToAdd=callbacksToAdd)
        history = self.model.fit(dataTrain, labelsTrain, batch_size=batchSize,
                                 epochs=nEpochs, validation_split=valSplit,
                                 validation_data=valData,
                                 callbacks=self.callbacks)

        if isSave:
            for metricsName in self.model.metrics_names:
                metric = history.history[metricsName]
                pd.DataFrame(metric).to_csv(os.path.join(self.dirResult,
                                                         f'{metricsName}.csv'))
                if valSplit > 0 or valData is not None:
                    metric = history.history[f'val_{metricsName}']
                    pd.DataFrame(metric).to_csv(os.path.join(self.dirResult,
                                                             f'val_{metricsName}.csv'))

        return history

    def create_callbacks(self, valSplit=0, valData=None, earlyStopping=False,
                         callbacksToAdd=None):

        """ This function creates callbacks list for the model training. See
        docstring for the <train> method.
        It creates a callback for saving model weights after each epoch in dirModel;
        If directory for logging exists in the instance of the net, it creates
        a callback for Tensorboard;
        If early stopping is selected, it creates a callback for early stopping
        (2 epochs of tolerance for cross-subject case, 4 epochs for within-subject)

        Inputs:

        valSplit        : float, in range between 0 and 1 - a proportion of
                            dataTrain to be held from training to calculate
                            validation metrics; default=0
        valSplit        : tuple, in the form (dataVal, labelsVal) - data and
                          labels to serve as validation dataset; default=None
        earlyStopping   : bool, if True stops the training when the validation
                            loss stops to improve; default=False
        """
        ### Callbacks
        # Model weights
        cpCallback = ModelCheckpoint(filepath=os.path.join(self.dirModel,
                                                           'cp.ckpt'),
                                     save_weights_only=True,
                                     verbose=1)
        # Model logs
        if self.dirLog:
            tbCallback = TensorBoard(self.dirLog)
        else:
            tbCallback = None
        # Early stopping
        if earlyStopping and self.design == 'within':
            esCallback = EarlyStopping(monitor='val_loss',
                                       patience=EPOCH_TOLERANCE_WITHIN,
                                       verbose=1)
        elif earlyStopping and self.design == 'cross':
            esCallback = EarlyStopping(monitor='val_loss',
                                       patience=EPOCH_TOLERANCE_CROSS,
                                       verbose=1)
        else:
            esCallback = None

        ### Added Nicolai from Dimitrii's old code version
        # Learning rates schedule
        if self.lrScheduler is not None:
            scheduleCallback = LearningRateScheduler(self.lrScheduler.step)
        else:
            scheduleCallback = None
        ###

        # Organize callbacks
        #callbacks = [cpCallback, tbCallback, esCallback]
        callbacks = [cpCallback, tbCallback, esCallback, scheduleCallback] # modified Nicolai
        if callbacksToAdd is not None:
            callbacks.append(callbacksToAdd)
        self.callbacks = list(filter(None, callbacks))
        if not callbacks:
            self.callbacks = None

        ### Make sure we have validation data for Early Stopping procedure
        if (valSplit > 0 or valData is not None) and earlyStopping:
            print('The training will stop when validation loss will '
                  'start to decrease')
        elif (valSplit == 0 or valData is None) and earlyStopping:
            raise ValueError ('If earlyStopping is true, you should have '
                              'a validation metrics to be monitored. '
                              'Please, consider increasing the value of valSplit'
                              ' or providing valData')

    def test(self, dataTest, batchSize=1):

        """ This function tests the trained network on the test data.

        Inputs:

        dataTest        : np.array, of shape (time_windows x channels x time),
                          which contains neural data to be tested
        batchSize       : int, number of time windows to be packed in one batch;
                          default=1, to be compatible with online inferring

        Outputs:

        predicted       : obj, np.array, predicted labels. If model
                          is compiled with 'categorical_crossentropy' loss
                          function, predicted is of shape (time_windows x
                          classes) with a number in the range between 0 and 1
                          in the corresponding column
        """

        predicted = self.model.predict(dataTest, batch_size=batchSize)

        return predicted

    def evaluate(self, predicted, labelsTest, isSave=True):

        """ This function calculated accuracy of the model given the predicted
        values.

        Inputs:

        predicted       : np.array, predicted labels. If model
                          is compiled with 'categorical_crossentropy' loss
                          function, predicted is of shape (time_windows x
                          classes) with a number in the range between 0 and 1
                          in the corresponding column
        labelsTest      : np.array, labels associated with data test. If model
                          is compiled with 'categorical_crossentropy' loss
                          function, labelsTest is of shape (time_windows x
                          classes) with 1 in the corresponding column if this
                          window belongs to this class, 0 otherwise
        isSave          : bool, if True saves accuracies for subjects if they
                          exist; default=False

        Outputs:

        accuracy        : float, mean accuracy of the model on the test set
        accuraciesSub   : list, accuracies of the model for each subject; if
                          maskSubTest is empty, accuraciesSub=[]

        """

        goodHits = np.equal(np.argmax(labelsTest, 1), np.argmax(predicted, 1))   # modified Nicolai
        accuracy = np.mean(goodHits)

        print(f'Accuracy of the model is {accuracy:.02%}')

        return accuracy

    def evaluate_fully(self, predicted, labelsTest, average='macro',
                       isSave=False):

        """ This function calculates basic metrics of the model given the predicted
        values (using sklearn.metrics functions):
        - accuracy
        - confusion matrix
        - f1-score
        - precision
        - recall
        It gives only dataset-wide metrics: if test dataset contains points
        from different subjects, it will not take it into account.

        Inputs:

        predicted       : np.array, predicted labels. If model
                          is compiled with 'categorical_crossentropy' loss
                          function, predicted is of shape (time_windows x
                          classes) with a number in the range between 0 and 1
                          in the corresponding column
        labelsTest      : np.array, labels associated with data test. If model
                          is compiled with 'categorical_crossentropy' loss
                          function, labelsTest is of shape (time_windows x
                          classes) with 1 in the corresponding column if this
                          window belongs to this class, 0 otherwise
        average         : str, type of averaging performed on the each metrics.
                          For more details, see sklearn.metrics documentation
        isSave          : bool, if True saves each metric in its own file,
                          default=False

        Outputs:

        metrics         : dict, with the following keys:
                            - accuracy
                            - confusion matrix
                            - f1-score
                            - precision
                            - recall

        """

        # Get int classes
        classPred = np.argmax(predicted, 1)
        classTrue = np.argmax(labelsTest, 1)

        # Calculate metrics for a given prediction
        # average="macro" means average metrics across all classes
        acc = accuracy_score(classTrue, classPred)
        confusionMatrix = confusion_matrix(classTrue, classPred)
        f1 = f1_score(classTrue, classPred, average=average)
        precision = precision_score(classTrue, classPred, average=average)
        recall = recall_score(classTrue, classPred, average=average)

        # Form a dictionary with metrics
        metrics = {'accuracy': acc, 'confusionMatrix': confusionMatrix,
                   'f1-score': f1, 'precision': precision, 'recall': recall}

        # Save metrics to a csv file
        if isSave:
            for key, value in metrics.items():
                if value.size > 1:
                    pd.DataFrame(value).to_csv(os.path.join(self.dirResult,
                                                            f'{key}.csv'))
                else:
                    pd.Series(value).to_csv(os.path.join(self.dirResult,
                                                         f'{key}.csv'))

        return metrics

    @staticmethod
    def decide_class(predicted, threshDecision=0.75):

        """ This function decides the prediction on the basis of several time
            windows classified.

        Inputs:

        predicted       : obj, np.array, predicted labels. If model
                          is compiled with 'categorical_crossentropy' loss
                          function, predicted is of shape (time_windows x
                          classes) with a number in the range between 0 and 1
                          in the corresponding column
        threshDecision  : float, between 0 and 1, respresents a fraction of
                          windows classified in the same class to announce
                          the classification result (aka confidence level);
                          default=0.75

        Outputs:

        decidedClass    : float, ordinal number of decided class if
                            classification has been made; or None, it has not
        predictedClasses: np.array, predicted class for each time window
        """

        # Check for nan values
        if np.isnan(predicted).any():
            raise ValueError('predicted contains nan values')

        predictedClasses = np.argmax(np.array(predicted), 1)
        uniqueClass = np.unique(predictedClasses)
        proportions = np.array([np.sum(predictedClasses==uni)/len(predictedClasses)
                                for uni in uniqueClass])
        winningClass = (proportions >= threshDecision)
        if np.sum(winningClass) > 0:
            return uniqueClass[winningClass][0], predictedClasses
        else:
            print('No conclusion was made by classifier')
            return None, predictedClasses

    def load_model(self):

        """ This function loads the weights of already trained instance of the
        same network.

        Inputs:

        None
        """

        if os.path.isfile(os.path.join(self.dirModel, 'cp.ckpt.index')):
            self.model.load_weights(os.path.join(self.dirModel, 'cp.ckpt'))
            print('Weights loaded successfully')
        else:
            print('No checkpoints found for this model. Most likely, the model'
                  ' was not trained')

    def save_parameters(self, nameFile='parameters'):

        """This function save parameters, idiosyncratic to this instance of
        the network in .json file at dirLog folder.

        Inputs:

        params          : obj, of class Params
        lPathSave       : str or path, folder to save
        nameFile        : str, optional. Name of the file to save
        """

        print('saving parameters and results')

        # Save parameters
        paramsD = vars(self.params)
        j = json.dumps(paramsD)
        f = open(os.path.join(self.dirLog, f'{nameFile}.json'), 'w')
        f.write(j)
        f.close()

