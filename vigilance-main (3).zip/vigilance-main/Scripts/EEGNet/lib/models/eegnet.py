# Description: EEGNet class derived from defaultnet of Mind and Act
# For the original code, see
# https://github.com/vlawhern/arl-eegmodels
# For the original paper, see
# https://iopscience.iop.org/article/10.1088/1741-2552/aace8c/meta
# #-Author: Dmitrii Bryzgalov (dmitrii.bryzgalov@capgemini.com) adapted from
# # Army Research Laboratory (ARL) EEGModels Project

# version 1.0.2
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Activation, Permute, Dropout
from tensorflow.keras.layers import Conv2D, MaxPooling2D, AveragePooling2D
from tensorflow.keras.layers import SeparableConv2D, DepthwiseConv2D
from tensorflow.keras.layers import BatchNormalization
from tensorflow.keras.layers import SpatialDropout2D
from tensorflow.keras.layers import Input, Flatten
from tensorflow.keras.constraints import max_norm

from .defaultnet import ANNet
from .deep_utils import manage_folders

class EEGNet(ANNet):
    """EEGNet class derived from defaultnet of Mind and Act

    """

    def __init__(self, nb_classes, Params, design='within',
                 dirModel=None, dirLog=None, dirResult=None):

        """ Keras Implementation of EEGNet
        https://iopscience.iop.org/article/10.1088/1741-2552/aace8c/meta
        Note that this implements the newest version of EEGNet and NOT the earlier
        version (version v1 and v2 on arxiv). We strongly recommend using this
        architecture as it performs much better and has nicer properties than
        our earlier version. For example:

            1. Depthwise Convolutions to learn spatial filters within a
            temporal convolution. The use of the depth_multiplier option maps
            exactly to the number of spatial filters learned within a temporal
            filter. This matches the setup of algorithms like FBCSP which learn
            spatial filters within each filter in a filter-bank. This also limits
            the number of free parameters to fit when compared to a fully-connected
            convolution.

            2. Separable Convolutions to learn how to optimally combine spatial
            filters across temporal bands. Separable Convolutions are Depthwise
            Convolutions followed by (1x1) Pointwise Convolutions.

        Inputs:

        nb_classes      : int, number of classes to classify
        Params          : obj, parameters for EEGNet
        design          : str, 'within' or 'cross'; default='within'
        dirModel        : path, to save the weights of the model
                          default - 'eegnet_modelX' in the current folder
        dirLogs         : path, path to save the tensorboard log and other logs;
                          default=None
        dirResults:     : path, to save the results; default - 'eegnet_results'
                          in the current folder
        """

        ### Network parameters
        self.nb_classes = nb_classes
        self.params = Params
        self.design = design
        if self.design != 'within' and self.design != 'cross':
            raise ValueError('design must be either "within" or "cross"')

        ### Initialize
        if self.params.dropoutType == 'SpatialDropout2D':
            dropoutType = SpatialDropout2D
        elif self.params.dropoutType == 'Dropout':
            dropoutType = Dropout
        else:
            raise ValueError('dropoutType must be one of SpatialDropout2D '
                             'or Dropout, passed as a string.')
        ##################################################################
        input1   = Input(shape=(self.params.chans, self.params.samples, 1))
        block1   = Conv2D(self.params.F1, (1, self.params.kernLength),
                          padding='same', input_shape=(self.params.chans,
                                                       self.params.samples, 1),
                          use_bias=False)(input1)
        block1   = BatchNormalization()(block1)
        block1   = DepthwiseConv2D((self.params.chans, 1), use_bias = False,
                                   depth_multiplier=self.params.D,
                                   depthwise_constraint=max_norm(1.))(block1)
        block1   = BatchNormalization()(block1)
        block1   = Activation('elu')(block1)
        block1   = AveragePooling2D((1, 4))(block1)
        block1   = dropoutType(self.params.dropoutRate)(block1)

        block2   = SeparableConv2D(self.params.F2, (1, 16),
                                   use_bias=False, padding='same')(block1)
        block2   = BatchNormalization()(block2)
        block2   = Activation('elu')(block2)
        block2   = AveragePooling2D((1, 8))(block2)
        block2   = dropoutType(self.params.dropoutRate)(block2)

        flatten  = Flatten(name='flatten')(block2)

        '''
        dense    = Dense(self.nb_classes, name='dense',
                         kernel_constraint=max_norm(Params.norm_rate))(flatten)
        softmax  = Activation('softmax', name='softmax')(dense)

        self.model = Model(inputs=input1, outputs=softmax)
        '''
        # Nicolai changed to sigmoid
        dense    = Dense(2, name='dense',
                         kernel_constraint=max_norm(Params.norm_rate))(flatten)
        sigmoid  = Activation('sigmoid', name='sigmoid')(dense)

        self.model = Model(inputs=input1, outputs=sigmoid)

        ### Folders (should be in the end because manage_folders creates folders
        # if there is an error upsteam, the folders avoid to be created)
        _dirModel, _dirLog, _dirResult = manage_folders(nameModel=EEGNet.__name__.lower(),
                                                        dirModel=dirModel,
                                                        dirLog=dirLog,
                                                        dirResult=dirResult)
        self.dirModel = _dirModel
        self.dirLog = _dirLog
        self.dirResult = _dirResult