# Basics of machine learning experiment tracking

When looking for optimal architecture or hyperparameters, very soon you will find 
yourself with dozens of slighly different folders, results and artefacts. To find
the good run or the clue to impromevements becomes very hard. This is where experiment 
tracking comes in handy. It allows you to keep track of all the experiments you run,
and to easily compare them.

### What do we track?
We aim to track as much as possible, namely:
* dataset version
* code version
* environment
* logs
* preprocessing parameters
* hyperparameters
* metrics during training
* results of training
* model_weights
* artefacts (e.g. plots, images, etc.)

### How do we track?
There are several third-party libraries that make tracking easy. For exhaustive list, 
please see [here](https://neptune.ai/blog/best-ml-experiment-tracking-tools). We 
use [Neptune.AI](https://neptune.ai/product/experiment-tracking). NeptuneAI is has a
wrapper that records the experiments parameters and metrics in a structured way, and
sends them to the NeptuneAI server. The server then allows you to browse the experiments
in a nice way, and to compare them. For full documentation, please see [here](https://docs.neptune.ai/).

## How do I start tracking?
To start tracking, you need to create a NeptuneAI account [here](https://app.neptune.ai/register).
Then, once you are logged in, you can create a new project - name it as you wish.

Voilà! To start logging experiments in your new project, you needed:
* to have an account name (gotten when registered)
* to have a project name (gotten when created a new project)
* to have a token (assigned to you when registered)

To start the tracking in your code, you need to (WARNING: this is not full code but a snippet):
```
from lib.tracking import NeptuneTracker
from lib.networks.eegnet import EEGNet

...

eegnet = EEGNet(3, params)
NeptuneTracker = NeptuneTracker(projectName=projectName, api=API,
                                dataDir='filesToTrack', params=params,
                                sourceFiles=['main.py', 'lib/tracking.py'])
neptuneTracker.create_run()
neptuneCallback = neptuneTracker.get_tensorflow_keras_callback()

...

# Run the training
eegnet.compile()
history = eegnet.train(trainData, trainLabels, 10, valSplit=0.2,
                           callbacksToAdd=neptuneCallback)
                           
# Log some more things
metricsToTrack = ['loss', 'accuracy', 'val_loss', 'val_accuracy']
for metricName in metricsToTrack:
neptuneTracker.log_parameters(metricName, history.history[metricName],
                              firstLevel='train')                                                        
```
Experiment will appear in your project web page. You can then browse the experiment and 
compare it with other experiments. You can also download the experiment files, and
reproduce the experiment.

**For full demonstration of Neptune.AI capabilities, please see or run [test_file](../../tests/neptune_wrapper_tests.py).
(Note that this is not a unittest test instance!!!)** 

## Tips
* To avoid entering name of your project and API token every time you run the code,
you can create a file called 'config.py' in `lib/tracking` folder and take the info
from there. It could take the following form:
```
API = 'WRkcmVzcyI...'
USER_NAME = user

def get_project_name(project):
    return f'{USER_NAME}/{project}'
```
* To avoid cluttering your project page, you can create a new project for each new architecture.